public class nearestLowestAndGreatestElement {
    public static void main(String[] args) {
        int[] arr = {10,20,30,40,60,70,90};
        int target = 72;
        int nearest = 0;
        int greatest = 0;
        int i = 0;
        int low = 0;
        int high = arr.length-1;
        while (i<arr.length) {
            int mid = (low+high) / 2;
            if(arr[mid] < target){
                nearest = arr[mid];
                low = mid + 1;
            }
            else if(arr[mid] > target){
                greatest = arr[mid];
                high = mid - 1;
            }
            else if(arr[mid] == target){
                nearest = greatest = arr[mid];
                return;
            }
            i++;
        }
        System.out.println("nearest = "+nearest);
        System.out.println("greatest = "+greatest);
    }
}
