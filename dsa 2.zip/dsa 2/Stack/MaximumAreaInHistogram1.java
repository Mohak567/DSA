package Stack;

import java.util.Stack;

public class MaximumAreaInHistogram1 {
    static int[] prevSmaller(int[] arr){
        int[] ans = new int[arr.length];

        Stack<Integer> st = new Stack<>();

        for(int i=0;i<arr.length;i++){

            while (!st.isEmpty() && arr[st.peek()]>=arr[i]) {
                st.pop();
            }

            if(st.isEmpty()){
                ans[i] = -1;
            }
            else{
                ans[i] = arr[st.peek()];
            }

            st.push(i);
        }
        return ans;
    }

    static int[] nextSmaller(int[] arr){
        int[] ans = new int[arr.length];

        Stack<Integer> st = new Stack<>();

        for(int i=arr.length-1;i>=0;i--){

            while (!st.isEmpty() && arr[st.peek()]>=arr[i]) {
                st.pop();
            }

            if(st.isEmpty()){
                ans[i] = -1;
            }
            else{
                ans[i] = arr[st.peek()];
            }

            st.push(i);
        }
        return ans;
    }
    public static void main(String[] args) {
        int[] arr = {6,2,5,4,5,1,6};
        int[] prevSmaller = prevSmaller(arr);
        int[] nextSmaller = nextSmaller(arr);

        //print
        // for(int i : prevSmaller){
        //     System.out.print(i+", ");
        // }

        // System.out.println();

        // for(int i : nextSmaller){
        //     System.out.print(i+", ");
        // }

        int maxArea = 0;

        for(int i=0;i<arr.length;i++){
            int width = (nextSmaller[i] - prevSmaller[i]) - 1;
            int area = arr[i] * width;
            maxArea = Math.max(maxArea, area);
        }
        System.out.println("Max Area = "+maxArea);
    }
}
