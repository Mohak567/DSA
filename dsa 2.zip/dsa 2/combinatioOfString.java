import java.util.ArrayList;

public class combinatioOfString {
    public static ArrayList<String> getcomb(String str){
        if(str.length() == 0){
            ArrayList<String> list = new ArrayList<>();
            list.add("");
            return list;
        }
        char c = str.charAt(0);
        ArrayList<String> result = new ArrayList<>();
        ArrayList<String> smallList = getcomb(str.substring(1));
        for(String s : smallList){
            for(int i=0;i<=s.length();i++){
                StringBuilder sb = new StringBuilder(s);
                sb.insert(i,c);
                result.add(sb.toString());
            }
        }
        return result;
    }
    public static void main(String[] args) {
        String str = "bac";
        System.out.println(getcomb(str));
    }
}
