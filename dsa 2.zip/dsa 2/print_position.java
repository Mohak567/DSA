import java.util.Arrays;

public class print_position {
    public static int[] find(int[] arr, int size, int index, int x) {
        if (index == arr.length) {
            int[] result = new int[size];
            return findPositions(arr, result, 0, 0, x);
        }
        if (arr[index] == x) {
            size++;
        }
        return find(arr, size, index + 1, x);
    }

    public static int[] findPositions(int[] arr, int[] result, int resIndex, int index, int x) {
        if (index == arr.length) {
            return result;
        }
        if (arr[index] == x) {
            result[resIndex++] = index;
        }
        return findPositions(arr, result, resIndex, index + 1, x);
    }

    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 10, 50, 20, 10};
        int x = 10;
        int[] positions = find(arr, 0, 0, x);
        System.out.println(Arrays.toString(positions));
    }
}
