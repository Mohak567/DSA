package Stack;

public class TwoStack {//using 1 array
    int capacity;
    int[] arr;
    int top1, top2;

    TwoStack(int capacity) {
        this.capacity = capacity;
        arr = new int[capacity];
        top1 = -1;
        top2 = capacity;
    }

    public void push1(int num) {
        if (top1 < top2 - 1) {
            arr[++top1] = num;
        } else {
            System.out.println("Stack 1 is full");
        }
    }

    public void push2(int num) {
        if (top1 < top2 - 1) {
            arr[--top2] = num;
        } else {
            System.out.println("Stack 2 is full");
        }
    }

    public int pop1() {
        if (top1 >= 0) {
            return arr[top1--];
        } else {
            throw new RuntimeException("Stack 1 underflow");
        }
    }

    public int pop2() {
        if (top2 < capacity) {
            return arr[top2++];
        } else {
            throw new RuntimeException("Stack 2 underflow");
        }
    }

    public boolean isEmpty1() {
        return top1 == -1;
    }

    public boolean isEmpty2() {
        return top2 == capacity;
    }

    public static void main(String[] args) {
        int capacity = 6;
        TwoStack obj = new TwoStack(capacity);

        obj.push1(1);
        obj.push1(2);
        obj.push1(3);
        obj.push1(4);
        obj.push1(5);
        obj.push2(6);
        
        System.out.println(obj.pop1());
        System.out.println(obj.pop2());
        System.out.println(obj.pop2());
    }
}
