package CP;

import java.math.BigInteger;

public class BigNumberAddition {

    static String reverse(String num){
        StringBuilder ans = new StringBuilder();
        for(int i=num.length()-1;i>=0;i--){
            ans.append(num.charAt(i));
        }
        return ans.toString();
    }

    static String Add(String a,String b){
        int carry = 0;
        a = reverse(a);
        b = reverse(b);
        int size = Math.max(a.length(), b.length());
        StringBuilder ans = new StringBuilder();
        int i = 0;
        for(i=0;i<size;i++){
            int num1 = a.length() > i ? a.charAt(i) - '0' : 0;
            int num2 = b.length() > i ? b.charAt(i) - '0' : 0;
            int temp = num1+num2+carry;
            carry = temp/10;
            ans.append(temp%10);
        }

        return ans.reverse().toString();

    }
    public static void main(String[] args) {
        String num1 = "3257689412385";
        String num2 = "68746886785688";
        // BigInteger b = new BigInteger(num1);
        // BigInteger a = new BigInteger(num2);
        // System.out.println(b.add(a));

        System.out.println(Add(num1,num2));
    }
}
