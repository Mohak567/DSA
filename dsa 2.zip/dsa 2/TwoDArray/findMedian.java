package TwoDArray;

import java.util.Arrays;

public class findMedian {
    public static void main(String[] args) {
        int[] a = {1,2,3};
        int[] b = {4,5,6};

        int[] arr = new int[a.length+b.length];

        // for(int i=0;i<arr.length;i++){
        //     if(a.length > i){
        //         arr[i] = a[i];
        //     }
        //     else{
        //         arr[i] = b[i - a.length];
        //     }
        // }
        //Arrays.sort(arr);

        int n = a.length;
        int m = b.length;
        int i = 0, j = 0, k = 0;

        while (i < n && j < m) {
            if (a[i] < b[j]) {
                arr[k++] = a[i++];
            } else {
                arr[k++] = b[j++];
            }
        }

        while (i < n) {
            arr[k++] = a[i++];
        }

        while (j < m) {
            arr[k++] = b[j++];
        }

        if(arr.length % 2 != 0){
            System.out.println("ans = "+arr[arr.length/2]);
        }
        else{
            double ans = 0;
            ans = arr[arr.length/2] + arr[(arr.length/2)-1];
            System.out.println("ans = "+ans/2);
        }
    }
}
