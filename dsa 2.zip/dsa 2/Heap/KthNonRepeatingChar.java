import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Map;

public class KthNonRepeatingChar {

    static void compute(String s,int k){
        HashMap<Character,Integer> m = new HashMap<>();
        PriorityQueue<Map.Entry<Character,Integer>> minHeap = new PriorityQueue<>((a,b) -> a.getValue() - b.getValue());

        for(int i=0;i<s.length();i++){
            char c = s.charAt(i);
            m.put(c,m.getOrDefault(c, 0)+1);
        }

        minHeap.addAll(m.entrySet());

        int j = 0;
        for(int i=0;i<k;i++){
            char c = s.charAt(j);
            if(m.get(c) == 1){
                System.out.println(c);
            }
            j++;
        }

    }

    public static void main(String[] args) {
        String s = "aaabccdeefggtth";
        compute(s,2);
    }
}