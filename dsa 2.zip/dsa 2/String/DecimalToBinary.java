public class DecimalToBinary {
    public static void main(String[] args) {
        int n = 15;
        StringBuilder sb = new StringBuilder();
        while(n>0){
            int bit = n&1;
            sb.append(bit);
            n = n>>1;
        }
        
        System.out.println(sb);
    }
}
