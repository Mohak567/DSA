package DP;

public class fibo {
    static int fib(int n){
        if(n <= 1){
            return n;
        }
        return fib(n-1)+fib(n-2);
    }

    static int fibMem(int n,int[] cache){//top down
        if(n <= 1) return n;
        if(cache[n] != 0) return cache[n];
        int a = fibMem(n-1, cache);
        int b = fibMem(n-2,cache);
        cache[n] = a+b;
        return a+b;
    }

    static int fibTab(int n,int[] cache){//bottom up
        cache[0] = 0;
        cache[1] = 1;
        for(int i=2;i<=n;i++){
            cache[i] = cache[i-1] + cache[i-2];
        }
        return cache[n];
    }
    public static void main(String[] args) {
        int n = 5;
        int[] cache = new int[n+1];
        System.out.println(fibTab(n,cache));
    }
}
