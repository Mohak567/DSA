package TwoDArray;
public class convertOneDToTwoD {
    public static int[][] Logic1(int[] arr,int row,int col){
        if(row * col != arr.length){
            int[][] a = new int[0][0];
            return a;
        }
        int[][] ans = new int[row][col];
        int index = 0;
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                ans[i][j] = arr[index];
                index++;
            }
        }
        return ans;
    }
    public static int[][] Logic2(int[] arr,int row,int col){
        if(row * col != arr.length){
            int[][] a = new int[0][0];
            return a;
        }
        int[][] ans = new int[row][col];
        int r = 0;
        int c = 0;
        for(int i=0;i<arr.length;i++){
            ans[r][c] = arr[i];
            c++;
            if(c == col){
                r++;
                c = 0;
            }
        }
        return ans;
    }
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6};
        int row = 2;
        int col = 3;
        // int[][] ans = Logic1(arr, row, col);
        int[][] ans = Logic2(arr, row, col);
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                System.out.print(ans[i][j]+" ");
            }
            System.out.println();
        }
    }
}