package DP;

public class editDistanceProblem {

    static int Recur(String a,String b,int m,int n){
        if(m == 0) return n;
        if(n == 0) return m;

        if(a.charAt(m-1) == b.charAt(n-1)){
            return Recur(a, b, m-1, n-1);
        }

        int insert = Recur(a, b, m-1, n);
        int delete = Recur(a, b, m, n-1);
        int replace = Recur(a, b, m-1, n-1);

        return 1 + Math.min(insert,Math.min(delete, replace));
    }

    static int Mem(String a,String b,int m,int n,int[][] cache){
        if(m == 0) return n;
        if(n == 0) return m;

        if(cache[m][n] != -1) return cache[m][n];

        if(a.charAt(m-1) == b.charAt(n-1)){
            cache[m][n] = Mem(a, b, m-1, n-1,cache);
        }
        else{
            int insert = Mem(a, b, m, n-1,cache);
            int delete = Mem(a, b, m-1, n,cache);
            int replace = Mem(a, b, m-1, n-1,cache);
            cache[m][n] = 1 + Math.min(insert, Math.min(replace, delete));
        }

        return cache[m][n];
    }

    static int Tab(String a,String b){
        int m = a.length();
        int n = b.length();
        int[][] mat = new int[m+1][n+1];
        for(int i=0;i<=m;i++){
            for(int j=0;j<=n;j++){
                if(i == 0){
                    mat[i][j] = j;
                }
                else if(j == 0){
                    mat[i][j] = i;
                }

                else{
                    if(a.charAt(i-1) == b.charAt(j-1)){
                        mat[i][j] = mat[i-1][j-1];
                    }
                    else{
                        int insert = mat[i-1][j];
                        int delete = mat[i][j-1];
                        int replace = mat[i-1][j-1];
                        int result = Math.min(replace, Math.min(delete, insert));
                        mat[i][j] = 1 + result;
                    }
                }
            }
        }

        return mat[m][n];


    }

    public static void main(String[] args) {
        String a = "sunday";
        String b = "saturday";
        int m = a.length();
        int n = b.length();
        // System.out.println(Recur(a,b,m,n));
        
        // int[][] cache = new int[m+1][n+1];
        // for (int i = 0; i <= m; i++) {
        //     for (int j = 0; j <= n; j++) {
        //         cache[i][j] = -1;
        //     }
        // }
        // System.out.println(Mem(a, b, m, n,cache));

        System.out.println(Tab(a, b));
    }
}
