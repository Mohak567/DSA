public class maxHeap {
    int[] maxHeap;
    int size;
    int capacity;
    public maxHeap(int capacity){
        this.capacity = capacity;
        this.size = 0;
        this.maxHeap = new int[capacity];
    }

    int parentIndex(int currentIndex){
        return (currentIndex -1) / 2;
    }

    int leftChildIndex(int index){
        return 2*index+1;
    }

    int rightChildIndex(int index){
        return 2*index+2;
    }

    void swap(int num1,int num2){
        int temp = maxHeap[num1];
        maxHeap[num1] = maxHeap[num2];
        maxHeap[num2] = temp;
    }

    int delete(){
        if(size == 0){
            System.out.println("underflow");
            return 0;
        }
        int x = maxHeap[0];
        maxHeap[0] = maxHeap[--size];
        maxHeapify(0);
        return x;
    }

    void maxHeapify(int index){
        int parent = index;
        int lci = 2*parent+1;
        int rci = 2*parent+2;
        while (lci < size && maxHeap[lci] > maxHeap[parent]) {
            parent = lci;
        }
        while (rci < size && maxHeap[rci] > maxHeap[parent]) {
            parent = rci;
        }

        if(parent != index){
            swap(index, parent);
            maxHeapify(parent);
        }
    }

    public void insert(int value){
        if(size == capacity){
            System.out.println("overflow");
            return;
        }
        int current = size;
        maxHeap[size++] = value;
        while(current > 0 && maxHeap[current] > maxHeap[parentIndex(current)]){
            swap(current,parentIndex(current));
            current = parentIndex(current);
        }
    }

    public static void main(String[] args) {
        maxHeap obj = new maxHeap(10);
        obj.insert(10);
        obj.insert(20);
        obj.insert(30);
        obj.insert(40);
        obj.insert(50);

        System.out.println(obj.delete());
    }

}
