public class atoi {
    public static void main(String[] args) {
        String s = "1337c0d3";
        boolean flag = true;
        int num=0;
        for(int i=0;i<s.length();i++){
            char c = s.charAt(i);
            int temp = c - '0';
            if(temp >=0 && temp <=9){
                num = num*10 + (s.charAt(i) - '0');
            }
            else if(c == '-'){
                flag = false;
            }
        }
        System.out.print(flag ? "" : "-");
        System.out.print(num);
    }
}
