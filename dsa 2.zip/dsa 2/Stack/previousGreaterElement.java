package Stack;

import java.util.Stack;

public class previousGreaterElement {
    public static void main(String[] args) {
        int[] arr = {60,50,40,30,85,90,60};
        Stack<Integer> st = new Stack<>();
        int[] ans = new int[arr.length];

        for(int i=0;i<arr.length;i++){
            while (!st.isEmpty() && st.peek() <= arr[i]) {
                st.pop();
            }
            if (st.isEmpty()) {
                ans[i] = -1;
            } else {
                ans[i] = st.peek();
            }
            st.push(arr[i]);
        }

        for(int i : ans){
            System.out.println(i);
        }
    }
}
