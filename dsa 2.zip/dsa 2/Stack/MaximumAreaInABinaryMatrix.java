package Stack;

import java.util.Stack;

public class MaximumAreaInABinaryMatrix {

  static int[] prevSmaller(int[] arr) {
    int[] ans = new int[arr.length];
    Stack<Integer> st = new Stack<>();

    for (int i = 0; i < arr.length; i++) {
      while (!st.isEmpty() && arr[st.peek()] >= arr[i]) {
        st.pop();
      }

      ans[i] = st.isEmpty() ? -1 : st.peek();
      st.push(i);
    }
    return ans;
  }

  static int[] nextSmaller(int[] arr) {
    int[] ans = new int[arr.length];
    Stack<Integer> st = new Stack<>();

    for (int i = arr.length - 1; i >= 0; i--) {
      while (!st.isEmpty() && arr[st.peek()] >= arr[i]) {
        st.pop();
      }

      ans[i] = st.isEmpty() ? arr.length : st.peek();
      st.push(i);
    }
    return ans;
  }

  public static int maxHistogram(int[] arr) {
    int[] prevSmaller = prevSmaller(arr);
    int[] nextSmaller = nextSmaller(arr);

    int maxArea = 0;

    for (int i = 0; i < arr.length; i++) {
      int width = nextSmaller[i] - prevSmaller[i] - 1;
      int area = arr[i] * width;
      maxArea = Math.max(maxArea, area);
    }

    return maxArea;
  }

  public static void main(String[] args) {
    int[][] matrix = {
      { 0, 1, 1, 1, 1, 0 },
      { 1, 1, 1, 1, 0, 1 },
      { 1, 1, 0, 1, 1, 1 },
      { 1, 1, 1, 1, 1, 0 },
    };

    int[] currRow = new int[matrix[0].length];
    System.arraycopy(matrix[0], 0, currRow, 0, matrix[0].length);

    int maxArea = maxHistogram(currRow);

    for (int i = 1; i < matrix.length; i++) {
      for (int j = 0; j < matrix[0].length; j++) {
        if (matrix[i][j] == 1) {
          currRow[j] += 1;
        } else {
          currRow[j] = 0;
        }
      }
      int currAns = maxHistogram(currRow);
      maxArea = Math.max(currAns, maxArea);
    }
    System.out.println(maxArea);
  }
}
