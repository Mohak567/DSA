import java.util.ArrayList;

public class PrefixSuffix {
    public static void main(String[] args) {
        String str = "abcd";
        //suffix
        StringBuilder s = new StringBuilder();
        ArrayList<String> result = new ArrayList<>();
        s.append(str.charAt(str.length() - 1));
        result.add(s.toString());
        for(int i=str.length()-2;i>=0;i--){
            char c = str.charAt(i);
            s.append(c);
            result.add(s.toString());
        }
        //prefix
        StringBuilder sb = new StringBuilder();
        ArrayList<String> list = new ArrayList<>();
        sb.append(str.charAt(0));
        list.add(sb.toString());
        for(int i=1;i<str.length();i++){
            char c = str.charAt(i);
            sb.append(c);
            list.add(sb.toString());
        }
        System.out.println(list);
        System.out.println(result);
    }
}
