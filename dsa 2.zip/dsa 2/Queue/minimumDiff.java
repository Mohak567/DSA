import java.util.PriorityQueue;

public class minimumDiff {

    static int find(int[] arr){
        if(arr.length == 1) return arr[0];
        else if(arr.length == 0) return -1;
        
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for(int i : arr){
            minHeap.offer(i);
        }

        int ans = Integer.MAX_VALUE;

        int top = minHeap.poll();
        while (!minHeap.isEmpty()) {
            int curr = minHeap.poll();
            int diff = curr - top;
            ans = Math.min(ans, diff);
        }

        return ans;
    }
    public static void main(String[] args) {
        int[] arr = {12,9,6,13,8,5};
        System.out.println(find(arr));
    }
}
