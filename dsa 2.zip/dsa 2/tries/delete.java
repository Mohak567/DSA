public class delete {
    static public class Node{
        Node[] children;
        boolean isTerminal;

        public Node(){
            children = new Node[26];
            for(int i=0;i<26;i++){
                children[i] = null;
            }
            isTerminal = false;
        }
    }

    static Node root = new Node();

    static public void insert(String word){
        Node currNode = root;
        for(int i=0;i<word.length();i++){
            int index = word.charAt(i) - 'a';
            if(currNode.children[index] == null){
                currNode.children[index] = new Node();
            }
            if(i == word.length()-1){
                currNode.children[index].isTerminal = true;
                System.out.println("word inserted = " +word);
            }
            currNode = currNode.children[index];
        }
    }

    static public boolean search(String word){
        Node curNode = root;
        for(int i=0;i<word.length();i++){
            int index = word.charAt(i) - 'a';
            Node NextNode = curNode.children[index];
            if(NextNode == null){
                return false;
            }
            if(i == word.length()-1 && NextNode.isTerminal == false){
                return false;
            }
            curNode = NextNode;
        }
        return true;
    }

    static public void del(String word){
        boolean flag = search(word);
        if(flag){
            Node currNode = root;
            for(int i=0;i<word.length();i++){
                int index = word.charAt(i) - 'a';
                Node NextNode = currNode.children[index];
                if(i == word.length() - 1 && NextNode.isTerminal == true){
                    NextNode.isTerminal = false;
                    System.out.println(word+" word is deleted");
                    return;
                }
                currNode = NextNode;
            }
        }
        else{
            System.out.println("word does not exist");
            return;
        }
    }
    public static void main(String[] args) {
        insert("owl");
        insert("apple");
        insert("ape");
        insert("ball");
        System.out.println(search("owl"));
        del("owl");
        System.out.println(search("owl"));
    }
}
