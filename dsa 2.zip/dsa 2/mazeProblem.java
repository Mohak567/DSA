import java.util.ArrayList;

public class mazeProblem {
    static  ArrayList<String> maze(int currentCol,int currentRow,int endCol,int endRow){
        if(currentCol == endCol && currentRow == endRow){
            ArrayList<String> list = new ArrayList<>();
            list.add("");
            return list;
        }
        if(currentCol > endCol || currentRow >endRow){
            ArrayList<String> list = new ArrayList<>();
            return list;
        }
        ArrayList<String> result = new ArrayList<>();
        ArrayList<String>right = maze(currentCol+1, currentRow, endCol, endRow);
        for(String s : right){
            result.add(s+"R");
        }
        ArrayList<String>down = maze(currentCol, currentRow+1, endCol, endRow);
        for(String s : down){
            result.add(s+"D");
        }
        return result;
    }
    public static void main(String[] args) {
        ArrayList<String> ans = maze(0,0,2,2);
        System.out.println(ans);
    }
}
