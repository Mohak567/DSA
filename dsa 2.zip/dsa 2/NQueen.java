public class NQueen{
    static boolean QueenSafe(boolean[][] board,int row,int col){
        for(int i=row;i>=0;i--){
            if(board[i][col]){
                return false;
            }
        }
        for(int i = row,j = col;i>=0&&j>=0;i--,j--){
            if(board[i][j]){
                return false;
            }
        }
        for(int i=row,j=col;i>=0&&j<board[row].length;i--,j++){
            if(board[i][j]){
                return false;
            }
        }
        return true;
    }

    static int places(boolean[][] board,int currentRow){
        if(currentRow == board.length){
            return 1;
        }
        int count = 0;
        for(int column=0;column<board[currentRow].length;column++){
            if(QueenSafe(board,currentRow,column)){
                board[currentRow][column] = true;
                int result = places(board, currentRow+1);
                count = count + result;
                //if fall
                board[currentRow][column] = false;
            }
        }
        return count;
    }
    public static void main(String[] args) {
        int N = 9;
        boolean[][] board = new boolean[N][N];
        int count = places(board,0);
        System.out.println(count);
    }
}