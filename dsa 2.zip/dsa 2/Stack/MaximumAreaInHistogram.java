package Stack;

import java.util.Stack;

public class MaximumAreaInHistogram {
    public static int getMaxArea(int[] height) {
        if (height == null || height.length == 0) {
            return 0;
        }
        int[] lessFromLeft = new int[height.length]; // idx of the first bar the left that is lower than current
        int[] lessFromRight = new int[height.length]; // idx of the first bar the right that is lower than current
        lessFromRight[height.length - 1] = height.length;
        lessFromLeft[0] = -1;
    
        for (int i = 1; i < height.length; i++) {
            int p = i - 1;
    
            while (p >= 0 && height[p] >= height[i]) {
                p = lessFromLeft[p];
            }
            lessFromLeft[i] = p;
        }
    
        for (int i = height.length - 2; i >= 0; i--) {
            int p = i + 1;
    
            while (p < height.length && height[p] >= height[i]) {
                p = lessFromRight[p];
            }
            lessFromRight[i] = p;
        }
    
        int maxArea = 0;
        for (int i = 0; i < height.length; i++) {
            maxArea = Math.max(maxArea, height[i] * (lessFromRight[i] - lessFromLeft[i] - 1));
        }
    
        return maxArea;
    }
    public static void main(String[] args) {
        int[] arr = {6,2,5,4,5,1,6};

        //itterative

        // int max = 0;
        // for(int i=0;i<arr.length;i++){

        //     int current = arr[i];
        //     //prev
        //     for(int j=i-1;j>=0;j--){
        //         if(arr[j] >= arr[i]){
        //             current += arr[i];
        //         }
        //         else{
        //             break;
        //         }
        //     }

        //     //next
        //     for(int j=i+1;j<arr.length;j++){
        //         if(arr[j] >= arr[i]){
        //             current += arr[i];
        //         }
        //         else{
        //             break;
        //         }
        //     }

        //     max = Math.max(current,max);
        // }
        // System.out.println(max);

        //more optimized
        // int maxArea = getMaxArea(arr);
        // System.out.println("Maximum area is: " + maxArea);

        //Stack

        Stack<Integer> st = new Stack<>();

        int n = arr.length;
        int maxArea = 0;

        for(int i=0;i<=n;i++){

            int currentHeight = (i==n) ? 0 : arr[i];

            while (!st.isEmpty() && currentHeight<arr[st.peek()]) {
                System.out.println(st.toString());
                int top = st.pop();
                System.out.println(st.toString());
                int width = st.isEmpty() ? i : i - st.peek() -1 ;
                int area = arr[top] * width;
                maxArea = Math.max(maxArea, area);
            }
            st.push(i);
            System.out.println(st.toString());
        }
        System.out.println(maxArea);
    }
}