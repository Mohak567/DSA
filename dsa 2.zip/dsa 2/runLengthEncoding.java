public class runLengthEncoding {
    public static int count(int index,String str){
        int temp = 0;
        for(int i=index;i<str.length()-1;i++){
            if(str.charAt(i) == str.charAt(i+1)){
                temp++;
            }
            else{
                break;
            }
        }
        return temp+1;
    }
    public static void main(String[] args) {
        String str = "aaaabbbccd";
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<str.length();i++){
            sb.append(str.charAt(i));
            int count = count(i,str);
            if(count>1){
                i += count;
                sb.append(count);
            }
        }
        System.out.println(sb.toString());
    }
}
