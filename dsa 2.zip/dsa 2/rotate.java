public class rotate {
    static void swap(int[] arr,int start,int end){
        while(start<end){
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;end--;
        }
    }
    public static void main(String[] args) {
        int[] arr = {10,20,30,40,50};
        int rotations = -3;
        if(rotations < 0){
            rotations += arr.length;
        }
        rotations = rotations % arr.length;
        swap(arr, 0, arr.length-1-rotations);
        swap(arr,arr.length - rotations, arr.length-1);
        swap(arr, 0, arr.length-1);
        for(int i : arr){
            System.out.print(i);
        }
    }
}
