public class bitOperations {
    public static void main(String[] args) {
        // int a = 4;
        // System.out.println((a&1) == 1 ? "odd" : "even");

        // // find the value of k position
        // int b = 20;
        // int k = 3;
        // int mask = 1<<k-1;
        // System.out.println((b&mask) > 0 ? "1" : "0");

        // //set the value to 1 at k position
        // int c = 5;
        // int k1 = 2;
        // int mask1 = 1<<k1-1;
        // System.out.println((c|mask1));

        // //set the value to 0 at k position
        // int d = 7;
        // int k2 = 2;
        // int mask2 = ~(1<<k2-1);
        // System.out.println((d&mask2));

        //power of 2 or not
        // int num = 64;
        // int temp = num & (num-1);
        // System.out.println(temp == 0 ? "power of 2" : "not a power of 2");
        
        //clear last i bits

        //approach 1

        // int i = 3;
        // int num = 23;
        // int temp = num>>i;
        // temp = temp<<i;
        // System.out.println(temp);

        //approach 2

        // int num = 23;
        // int mask = (~0<<3);
        // System.out.println((num&mask));

        //to find the signs of the bits
        // int a=5;
        // int b=-6;
        // System.out.println((a^b) >= 0 ? "same" : "different");

        //find unique element in array
        // int[] arr = {1,2,3,5,6,4,5,1,2,3,4};
        // int ans = 0;
        // for(int i : arr){
        //     ans = ans ^ i;
        // }

        // System.out.println(ans);

        //increment the number by 1
        //~n = -(n+1)
        // int n = 5;
        // int temp = ~n;
        // System.out.println(temp*-1);

        //multipy the number n by 2.5 without using * operator
        //this can be done on 2's power values
        //2.5 can be written in 2 + 0.5
        // int n = 5;
        // int temp = (n << 1) + (n>>1);
        // System.out.println(temp);

        // //4.5
        // int num = 5;
        // int t = (((num<<2)) + (n>>1));
        // System.out.println(t);

        //perform xor without xor operator

        // int a = 1;
        // int b = 0;
        // int temp = ((a & ~b) + (b & ~a));
        // System.out.println(temp);

        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        // //find max                                          x     
        // int[] arr = {1,2,3,4,5,6,7};                        x
        // int max = 0;                                        x
        // for(int i=0;i<arr.length;i++){                      x
        //     for(int j=i+1;j<arr.length;j++){                x
        //         int tempMax = arr[i] & arr[j];              x
        //         if(max<tempMax){                            x
        //             max = tempMax;                          x
        //         }                                           x
        //     }                                               x
        // }                                                   x
        // System.out.println(max);                            x
        //xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 
        
        //1s complement;
        int N = 5;
        if (N == 0) {
            System.out.println(1);
            return;
        }
        int bitLength = Integer.toBinaryString(N).length();
        int mask = (1 << bitLength) - 1;
        System.out.println(N ^ mask);
    }
}
