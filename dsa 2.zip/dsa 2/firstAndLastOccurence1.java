public class firstAndLastOccurence1 {
    public static void main(String[] args) {
        int[] arr = {1,3,4,2,6,5,7,7};
        int ans = -1;

        for(int i=0;i<arr.length;i++){
            int element = Math.abs(arr[i]);
            if(arr[element] < 0){
                ans = element;
                break;
            }
            arr[element] = arr[element] * -1;
        }
        System.out.println(ans);
    }
}
