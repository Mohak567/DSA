import java.util.Collections;
import java.util.PriorityQueue;

public class Median {

    static PriorityQueue<Integer> minHeap = new PriorityQueue<>();
    static PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder());

    static void compute(int[] arr){
        for(int i : arr){
            if(maxHeap.isEmpty() || maxHeap.peek()>= i){
                maxHeap.offer(i);
            }
            else {
                minHeap.offer(i);
            }

            if(maxHeap.size() > minHeap.size() + 1){
                minHeap.offer(maxHeap.poll());
            }

            else if(maxHeap.size() < minHeap.size()){
                maxHeap.offer(minHeap.poll());
            }

        }
    }

    static int findMedian(int[] arr){
        compute(arr);

        if(maxHeap.size() == minHeap.size()){
            return maxHeap.peek();
        }
        else{
            return (minHeap.peek() + maxHeap.peek()) / 2;
        }
    }

    static void median(int[] arr){
        PriorityQueue<Integer> min = new PriorityQueue<>();
        PriorityQueue<Integer> max = new PriorityQueue<>(Collections.reverseOrder());

        for (int i = 0; i < arr.length; i++) {
            max.offer(arr[i]);
            min.offer(max.poll());
            if(max.size() < min.size()){
                max.offer(min.poll());
            }
        }

        if(max.size() == min.size()){
            System.out.println((min.peek()+max.peek())/2.0);
        }
        else{
            System.out.println(max.peek());
        }
    }
    public static void main(String[] args) {
        int[] arr = {1,5,9,7,3,4};
        // System.out.println(findMedian(arr));
        median(arr);
    }
}
