public class KMP {
        static int[] computeWeight(String Pattern){
        int[] arr = new int[Pattern.length()];
        int j = 1;
        int i = 0;
        while(j<Pattern.length()){
            if(Pattern.charAt(i) == Pattern.charAt(j)){
                i++;
                arr[j] = i;
                j++;
            }
            else{
                if(i != 0){
                    i = arr[i-1];
                }
                else{
                    arr[j] = 0;
                    j++;
                }
            }
        }
        return arr;
    }

    static int findPattern(String text,String Pattern,int[] weightArr){
        int i = 0;
        int j = 0;
        while (i<text.length()) {
            if(text.charAt(i) == Pattern.charAt(j)){
                i++;j++;
                if(j==Pattern.length()){
                    return i-j;
                }
            }
            else{
                if(j!=0){
                    j = weightArr[j-1];
                }
                else{
                    i++;
                }
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        String text = "ababuchabcabyababy";
        String Pattern = "abcaby";
        int[] arr = computeWeight(Pattern);
        int ans = findPattern(text,Pattern,arr);
        if(ans == -1){
            System.out.println("not Present in the text");
        }
        else{
            System.out.println("Pattern is from = "+ans+" to = "+(Pattern.length()+ans));
        }
    }
}
