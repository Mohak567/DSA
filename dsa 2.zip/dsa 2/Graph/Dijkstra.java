package Graph;

import java.util.Arrays;

public class Dijkstra {

    static int[] dijkstraImplementation(int v,int[][] graph){
        boolean[] visited = new boolean[v];
        int[] distance = new int[v];
        Arrays.fill(distance,Integer.MAX_VALUE);
        distance[0] = 0;
        for(int i=0;i<v-1;i++){
            int u = -1;
            for(int j=0;j<v;j++){
                if(!visited[j] && (u == -1 || distance[j] < distance[u])){
                    u = j;
                }
            }
            visited[u] = true;
            for(int vertex = 0;vertex<v;vertex++){
                if(graph[u][vertex] != 0 && !visited[vertex]){
                    distance[vertex] = Math.min(distance[u]+graph[u][vertex],distance[vertex]);
                }
            }
        }

        return distance;
    }

    public static void main(String[] args) {
        int[][] graph = {
            {0, 5, 8, 0},
            {5, 0, 10, 15},
            {8, 10, 0, 20},
            {0, 15, 20, 0}
        };
        int vertex = 4;
        int[] ans = dijkstraImplementation(vertex,graph);
        for(int i : ans){
            System.out.print(i+",");
        }
    }

}