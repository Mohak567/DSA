public class LCP {//longest common prefix

    static int min(String[] arr,int n){
        int min = arr[0].length();
        for(int i=1;i<n;i++){
            if(arr[i].length() < min){
                min = arr[i].length();
            }
        }
        return min;
    }
    
    static String lcp(String[] arr,int n){
        int minLength = min(arr,n);
        String ans = "";
        for(int i=0;i<minLength;i++){
            char c = arr[0].charAt(i);
            for(int j=1;j<n;j++){
                if(arr[j].charAt(i) != c){
                    return ans;
                }
            }
            ans += c;
        }

        if(ans.isEmpty()){
            System.out.println("no LCP present");
        }

        return ans;
    }
    public static void main(String[] args) {
        String[] arr = {"lies","listen","list"};
        int n = arr.length;
        System.out.println(lcp(arr,n));
    }
}
