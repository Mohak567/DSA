public class towerOfHanoi {
    static void find(int n,char a,char b,char c){
        if(n == 1){
            System.out.println(a+"-->"+c);
            return;
        } 
        find(n-1, a, c, b);
        find(1, a, b, c);
        find(n-1, b, a, c);

    }
    public static void main(String[] args) {
        find(4,'A','B','C');
    }
}
