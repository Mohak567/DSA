package Stack;

import java.util.Stack;

public class infixToPostfix {
    public static int precidence(char c){
        if(c == '^'){
            return 3;
        }
        else if(c == '/' || c == '*'){
            return 2;
        }
        else if (c == '+' || c == '-') {
            return 1;
        }
        return -1;
    }

    public static String infixToPostfix1(String exp){
        Stack<Character> stack = new Stack<>();
        StringBuilder sb = new StringBuilder();

        for(int i=0;i<exp.length();i++){

            char c = exp.charAt(i);
            if(Character.isAlphabetic(c)){
                sb.append(c);
            }

            else if(c == '('){
                stack.push('(');
            }
            
            else if(c == ')'){
                while (!stack.isEmpty() && stack.peek() != '(') {
                    sb.append(stack.pop());
                }
                stack.pop();
            }

            else{
                while (!stack.isEmpty() && precidence(stack.peek()) >= precidence(c)) {
                    sb.append(stack.pop());
                }
                stack.push(c);
            }
        }
        while (!stack.isEmpty()) {
            sb.append(stack.pop());
        }
        return sb.toString();
    }
    public static void main(String[] args) {
        String exp = "a*b+(c/d)";
        System.out.println(infixToPostfix1(exp));
    }
}
