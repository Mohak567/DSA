public class computeWeight1 {
    public static void main(String[] args) {
        String Pattern = "abcaby";
        int[] arr = new int[Pattern.length()];
        int j = 1;
        int i = 0;
        while(j<Pattern.length()){
            if(Pattern.charAt(i) == Pattern.charAt(j)){
                i++;
                arr[j] = i;
                j++;
            }
            else{
                if(i != 0){
                    // int temp = 0;
                    i = arr[i-1];
                    // arr[j] = arr[temp];
                }
                else{
                    arr[j] = 0;
                    j++;
                }
            }
        }
        for(int num : arr){
            System.out.println(num);
        }
    }
}
