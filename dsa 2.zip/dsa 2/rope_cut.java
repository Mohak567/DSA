public class rope_cut {
    static int findMaxCut(int size,int a,int b,int c){
        if(size < 0){
            return -1;
        }
        else if(size == 0){
            return 0;
        }
        int Aans = findMaxCut(size-a, a, b, c);
        int Bans = findMaxCut(size-b, a, b, c);
        int Cans = findMaxCut(size-c, a, b, c);

        int pieces = Math.max(Math.max(Aans, Bans),Cans);

        if(pieces == -1){
            return -1;
        }

        return pieces + 1;
    }
    public static void main(String[] args) {
        int size = 9;
        int a = 3,b=4,c=5;
        System.out.println(findMaxCut(size,a,b,c));
    }
}
