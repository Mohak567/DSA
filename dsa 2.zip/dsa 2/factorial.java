public class factorial {
    public static void facto(int n,int mux){
        if(n == 1 || n == 0){
            System.out.println(mux);
            return;
        }
        mux *= n;
        facto(n-1,mux);
        return;
    }

    public static int factoR(int n){
        if(n == 1 || n == 0){
            return 1;
        }
        int mux = factoR(n-1);
        return mux * n;
    }
    public static void main(String[] args) {
        int n = 5;
        facto(n,1);
        System.out.println(factoR(n));
    }
}
