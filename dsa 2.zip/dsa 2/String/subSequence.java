import java.util.ArrayList;

public class subSequence {
    public static ArrayList<String> findSubSequence(String s){
        ArrayList<String> list = new ArrayList<>();
        for(int i=0;i<s.length();i++){
            char c = s.charAt(i);
            if(list.size() == 0){
                list.add("");
                list.add(""+c);
                continue;
            }
            int subLength = list.size();
            for(int j=0;j<subLength;j++){
                String temp = list.get(j) + c;
                list.add(temp);
            }
        }
        return list;
    }
    public static void main(String[] args) {
        String s = "abc";
        ArrayList<String> list = findSubSequence(s);
        System.out.println(list);
    }
}
