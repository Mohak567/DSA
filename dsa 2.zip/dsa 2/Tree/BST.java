package Tree;

class BSTNodes<T>{
    T data;
    BSTNodes left;
    BSTNodes right;

    BSTNodes(T data){
        this.data = data;
    }
}

class BSTOperations{
    BSTNodes<Integer> root;
    void TakeTreeValues(){
        root = insert(root, 30);
        BSTNodes<Integer> t = insert(root,20);
        t = insert(root, 5);
        t = insert(root, 10);
        print(root);
        BSTNodes<Integer> ans = search(root, 5);
        System.out.println(ans == null ? "not found" : "data found "+ans.data);
        System.out.println(minimum(root));
        System.out.println(maximum(root));
    }
    BSTNodes<Integer> insert(BSTNodes<Integer> currentNode, int data){
        if(currentNode == null){
            currentNode = new BSTNodes<>(data);
            return currentNode;
        }
        if(currentNode.data > data){
            currentNode.left = insert(currentNode.left, data);
        }
        else if(currentNode.data < data){
            currentNode.right = insert(currentNode.right, data);
        }
        return currentNode;
    }

    void print(BSTNodes<Integer> curr){
        if(curr != null){
            print(curr.left);
            System.out.println(curr.data);
            print(curr.right);
        }
    }

    BSTNodes<Integer> search(BSTNodes<Integer> curr,int searchElement){
        if(curr == null || curr.data == searchElement){
            return curr;
        }
        if(curr.data > searchElement){
            return search(curr.left,searchElement);
        }
        else{
            return search(curr.right,searchElement);
        }
    }

    int minimum(BSTNodes<Integer> curr){
        if(curr == null){
            return -1;
        }
        int min = Integer.MAX_VALUE;
        min = curr.data;

        while(curr.left != null){
            min = (Integer)curr.left.data;
            curr = curr.left;
        }
        return min;
    }

    int maximum(BSTNodes<Integer> curr){
        if(curr == null){
            return -1;
        }
        int max = Integer.MIN_VALUE;
        max = curr.data;

        while(curr.right != null){
            max = (Integer)curr.right.data;
            curr = curr.right;
        }
        return max;
    }

    void remove(BSTNodes<Integer> curr,BSTNodes<Integer> parent,boolean isLeft,int data){
        if(curr.data < data){
            remove(curr.right, curr, false, data);
        }
        else if(curr.data > data){
            remove(curr.left, curr, true, data);
        }
        else{
            //leaf Node
            if(curr.left == null && curr.right == null){
                if(isLeft){
                    parent.left = null;
                }
                else{
                    parent.right = null;
                }
            }

            else if(curr.left == null && curr.right != null){
                if(isLeft){
                    parent.left = curr.right;
                }
                else{
                    parent.right = curr.right;
                }
                curr.right = null;
            }

            else if(curr.left != null && curr.right == null){
                if(isLeft){
                    parent.left = curr.left;
                }
                else{
                    parent.right = curr.left;
                }
                curr.left = null;
            }

            else if(curr.left == null && curr.right == null){
                //left max
                int max = maximum(curr.left);
                curr.data = max;
                remove(curr.left, curr, true, max);

            }
        }
    }
}

public class BST {
    public static void main(String[] args) {
        BSTOperations obj = new BSTOperations();
        obj.TakeTreeValues();
    }
}
