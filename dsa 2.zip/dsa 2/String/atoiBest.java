public class atoiBest {
    public static void main(String[] args) {
        String ss = "4565uyg";
        String s = ss.replaceAll("[^0-9]" , "");
        System.out.println(Integer.valueOf(s));
        System.out.println(Integer.parseInt(s));
    }
}
