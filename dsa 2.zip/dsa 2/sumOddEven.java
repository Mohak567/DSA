public class sumOddEven {
    public static int[] sum(int num,int index){
        if(num == 0){
            int[] result = new int[2];
            return result;
        }
        int[] arr = sum(num/10, index+1);
        int digit = num % 10;
        if(index % 2 == 0){
            arr[0] = arr[0]+digit;
        }
        else{
            arr[1] = arr[1] + digit;
        }
        return arr;
    }
    public static void main(String[] args) {
        int num = 1234;
        int[] ans = sum(num,0);
        System.out.println("odd " + ans[0]);
        System.out.println("even " + ans[1]);
    }
}
