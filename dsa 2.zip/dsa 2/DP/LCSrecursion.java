package DP;

public class LCSrecursion {

    static int Recur(String a,String b){
        if(a.length() == 0 || b.length() == 0) return 0;
        int count = 0;
        if(a.charAt(0) == b.charAt(0)){
            count = 1 + Recur(a.substring(1), b.substring(1));
        }
        else{
            int subT1 = Recur(a.substring(1), b);
            int subT2 = Recur(a, b.substring(1));
            count += Math.max(subT1, subT2);
        }
        return count;
    }

    static int Mem(String a,String b,int m,int n,int[][] cache){
        if(m == 0 || n == 0) return 0;
        if(cache[m-1][n-1] != 0){
            return cache[m-1][n-1];
        }

        if(a.charAt(m-1) == b.charAt(n-1)){
            cache[m-1][n-1] = 1 + Mem(a, b, m-1, n-1, cache);
            return cache[m-1][n-1];
        }
        else{
            int subT1 = Mem(a, b, m-1, n, cache);
            int subT2 = Mem(a, b, m, n-1, cache);
            cache[m-1][n-1] = Math.max(subT1, subT2);
            return cache[m-1][n-1];
        }
    }

    static int Tab(String a,String b){
        int[][] matrix = new int[a.length()+1][b.length()+1];
        for(int i=0;i<=a.length();i++){
            for(int j=0;j<=b.length();j++){
                if(i == 0 || j == 0){
                    matrix[i][j] = 0;
                }

                else{
                    if(a.charAt(i-1) == b.charAt(j-1)){
                        matrix[i][j] = 1 + matrix[i-1][j-1];
                    }
                    else{
                        matrix[i][j] = Math.max(matrix[i-1][j], matrix[i][j-1]);
                    }
                }
            }
        }
        return matrix[a.length()][b.length()];
    }

    public static void main(String[] args) {
        String a = "abcjkl";
        String b = "jhcjka";
        // System.out.println(Recur(a,b));
        
        // int[][] cache = new int[a.length()][b.length()];
        // System.out.println(Mem(a,b,a.length(),b.length(),cache));

        System.out.println(Tab(a, b));
    }
}
