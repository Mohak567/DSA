package Graph;

import java.util.ArrayList;

public class DetectCycle {

    static void addEdge(ArrayList<ArrayList<Integer>> adj,int u,int v){
        adj.get(v).add(u);
        adj.get(u).add(v);
    }

    static boolean dfsRec(ArrayList<ArrayList<Integer>> adj,int source,boolean[] visited,int parentNode){
        visited[source] = true;
        for(int i : adj.get(source)){
            if(visited[i] == false){
                if (dfsRec(adj, i, visited,source)) {
                    return true;
                }
            }
            else if (i != parentNode) {
                return true;
            }
        }
        return false;
    }

    static boolean dfs(ArrayList<ArrayList<Integer>> adj,int v,int source){
        boolean[] visited = new boolean[v];
        // dfsRec(adj, source, visited);
        
        //for disconnected
        for(int i=0;i<v;i++){
            if(visited[i] == false){
                if(dfsRec(adj, i, visited,-1)){
                    return true;
                }
            }
        }
        return false;
    }

    public static void main(String[] args) {
        int totalVertex = 4;
        ArrayList<ArrayList<Integer>> adj = new ArrayList<>();
        for(int i=0;i<totalVertex;i++){
            adj.add(new ArrayList<>());
        }

        addEdge(adj, 0, 1);
        addEdge(adj, 1, 2);
        addEdge(adj, 2, 3);
        // addEdge(adj, 3, 0);

        System.out.println(dfs(adj, totalVertex, 0));;
    }
}
