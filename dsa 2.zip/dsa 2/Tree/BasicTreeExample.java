package Tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.TreeMap;

class BinaryTreeNode<T>{
    T data;
    BinaryTreeNode<T> left;
    BinaryTreeNode<T> right;

    BinaryTreeNode(T data){
        this.data = data;
    }
}

class BasicTreeOprations{
    String nodeName = "root";
    Scanner sc = new Scanner(System.in);

    BinaryTreeNode<Integer> insert(){
        System.out.println("enter tha data for "+nodeName+" node");
        System.out.println("u want to exit type -1");

        int data = sc.nextInt();

        if(data == -1){
            return null;
        }

        BinaryTreeNode<Integer> newNode = new BinaryTreeNode<>(data);

        //dft
        nodeName = "left";
        newNode.left = insert();

        nodeName = "right";
        newNode.right = insert();

        nodeName = "root";
        return newNode;
    }

    void print(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }
        String result = "";

        result += root.data+" --> ";
        if(root.left != null){
            result += " left "+root.left.data;
        }
        if(root.right != null){
            result += " right "+root.right.data;
        }
        System.out.println(result);
        print(root.left);
        print(root.right);
        
    }

    //dft
    void preOrder(BinaryTreeNode<Integer> root){//PLR
        if(root == null){
            return;
        }
        System.out.println(root.data);
        preOrder(root.left);
        preOrder(root.right);
    }

    void inOrder(BinaryTreeNode<Integer> root){//LPR
        if(root == null){
            return;
        }
        inOrder(root.left);
        System.out.println(root);
        inOrder(root.right);
    }

    void postOrder(BinaryTreeNode<Integer> root){//LRP
        if(root == null){
            return;
        }
        postOrder(root.left);
        postOrder(root.right);
        System.out.println(root.data);
    }

    //Iterative
    void preOrderIterative(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }

        Stack<BinaryTreeNode<Integer>> stack = new Stack<>();
        stack.push(root);
        while(!stack.isEmpty()){
            BinaryTreeNode<Integer> current = stack.pop();
            System.out.println(current.data+", ");
            if(current.right != null){
                stack.push(current.right);
            }
            if(current.left != null){
                stack.push(current.left);
            }
        }
        System.out.println();
    }

    //more optimized
    void preOrderIterative1(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }

        Stack<BinaryTreeNode<Integer>> stack = new Stack<>();
        BinaryTreeNode<Integer> current = stack.push(root);
        while(current != null || !stack.isEmpty()){
            while (current != null) {
                System.out.println(current.data+", ");
                if (current.right != null) {
                    stack.push(current.right);
                }
                current = current.left;
            }
            if(!stack.isEmpty()){
                current = stack.pop();
            }
        }
        System.out.println();
    }
    //

    void inOrderIterative(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }
        Stack<BinaryTreeNode<Integer>> stack = new Stack<>();
        BinaryTreeNode<Integer> current = root;

        while (current != null || !stack.isEmpty()) {
            while (current != null) {
                stack.push(current);
                current = current.left;
            }

            current = stack.pop();
            System.out.println(current.data+", ");
            current = current.right;
        }
    }

    void postOrderIterative(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }

        Stack<BinaryTreeNode<Integer>> stack1 = new Stack<>();
        Stack<BinaryTreeNode<Integer>> stack2 = new Stack<>();

        stack1.push(root);

        while (!stack1.isEmpty()) {
            BinaryTreeNode<Integer> current = stack1.pop();
            stack2.push(current);

            if(current.left != null){
                stack1.push(current.left);
            }
            if(current.right != null){
                stack1.push(current.right);
            }
        }

        while (!stack2.isEmpty()) {
            System.out.print(stack2.pop().data+", ");
        }
        System.out.println();
    }

    //BFT
    void BFT(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }

        LinkedList<BinaryTreeNode<Integer>> queue = new LinkedList<>();

        queue.addFirst(root);
        while (!queue.isEmpty()) {
            BinaryTreeNode<Integer> current = queue.removeLast();
            System.out.print(current.data+", ");

            if(current.left != null){
                queue.addFirst(current.left);
            }
            if(current.right != null){
                queue.addFirst(current.right);
            }
        }
        System.out.println();
    }

    //good representation
    void BFT1(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }

        LinkedList<BinaryTreeNode<Integer>> queue = new LinkedList<>();

        queue.addFirst(root);
        while (!queue.isEmpty()) {
            int size = queue.size();
            for(int i=0;i<size;i++){
                BinaryTreeNode<Integer> current = queue.removeLast();
                System.out.print(current.data+", ");

                if(current.left != null){
                    queue.addFirst(current.left);
                }
                if(current.right != null){
                    queue.addFirst(current.right);
                }
            }
            System.out.println();
        }
    }

    int height(BinaryTreeNode<Integer> root){
        if(root == null){
            return 0;
        }

        int leftH = height(root.left);
        int rightH = height(root.right);

        int max = Math.max(leftH, rightH);
        return max + 1;
    }

    int numOfNodes(BinaryTreeNode<Integer> root){
        if (root == null) {
            return 0;
        }
        int counter = 1;
        counter += numOfNodes(root.left);
        counter += numOfNodes(root.right);

        return counter;
    }

    int maxLevelL = 0;
    void leftView(BinaryTreeNode<Integer> root,int currentLevel){
        if(root == null){
            return;
        }
        if (currentLevel > maxLevelL) {
            System.out.print(root.data+" ,");
            maxLevelL = currentLevel;
        }
        leftView(root.left, currentLevel+1);
        leftView(root.right, currentLevel+1);
    }

    int maxLevelR = 0;
    void rightView(BinaryTreeNode<Integer> root,int currentLevel){
        if(root == null){
            return;
        }
        if (currentLevel > maxLevelR) {
            System.out.print(root.data+" ,");
            maxLevelR = currentLevel;
        }
        rightView(root.right, currentLevel+1);
        rightView(root.left, currentLevel+1);
    }

    void leftViewI(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }
        Queue<BinaryTreeNode<Integer>> q = new LinkedList<>();
        q.offer(root);
        while (!q.isEmpty()) {
            int size = q.size();
            for(int i=0;i<size;i++){
                BinaryTreeNode<Integer> curr = q.poll();
                if(i == 0){
                    System.out.println(curr.data);
                }
                if (curr.left != null) {
                    q.offer(curr.left);
                }
                if (curr.right != null) {
                    q.offer(curr.right);
                }
            }
        }
    }

    void rightViewI(BinaryTreeNode<Integer> root){
        if(root == null){
            return;
        }
        Queue<BinaryTreeNode<Integer>> q = new LinkedList<>();
        q.offer(root);
        while (!q.isEmpty()) {
            int size = q.size();
            for(int i=0;i<size;i++){
                BinaryTreeNode<Integer> curr = q.poll();
                if(i == 0){
                    System.out.println(curr.data);
                }
                if (curr.right != null) {
                    q.offer(curr.right);
                }
                if (curr.left != null) {
                    q.offer(curr.left);
                }
            }
        }
    }

    void verticalOrder(BinaryTreeNode<Integer> root,int distance,TreeMap<Integer,ArrayList<Integer>> map){
        if(root == null){
            return;
        }

        if(map.get(distance) == null){
            ArrayList<Integer> list = new ArrayList<>();
            list.add(root.data);
            map.put(distance, list);
        }
        else{
            ArrayList<Integer> list = map.get(distance);
            list.add(root.data);
            map.put(distance, list);
        }

        verticalOrder(root.left, distance-1, map);
        verticalOrder(root.right, distance+1, map);
    }

    void PrintVerticalOrder(BinaryTreeNode<Integer> root){
        if ((root == null)) {
            return;
        }

        TreeMap<Integer,ArrayList<Integer>> map = new TreeMap<>();

        verticalOrder(root, 0, map);

        for(Map.Entry<Integer,ArrayList<Integer>> m : map.entrySet()){
            System.out.println(m.getKey()+" - "+m.getValue());
        }
    }


    Map<Integer, TreeMap<Integer, PriorityQueue<Integer>>> map;
    
    public List<List<Integer>> verticalTraversal(BinaryTreeNode<Integer> root) {
        if (root == null){
            return null;
        }
        map = new TreeMap<>();
        dfs(root, 0, 0);
        List<List<Integer>> res = new LinkedList<>();
        for (int key : map.keySet()){
            List<Integer> list = new LinkedList<>();
            TreeMap<Integer, PriorityQueue<Integer>> tm = map.get(key);
            for (int k : tm.keySet()){
                PriorityQueue<Integer> pq = tm.get(k);
                while (!pq.isEmpty()){
                    list.add(pq.poll());
                }
            }
            res.add(list);
        }
        return res;
    }
    
    public void dfs(BinaryTreeNode<Integer> root, int index, int level){
        if (root == null){
            return;
        }
        
        map.putIfAbsent(index, new TreeMap<>());
        map.get(index).putIfAbsent(level, new PriorityQueue<>());
        map.get(index).get(level).add(root.data);
        dfs(root.left, index - 1, level + 1);
        dfs(root.right, index + 1, level + 1);
    }

    void topView(BinaryTreeNode<Integer> root,TreeMap<Integer,Integer> tm,int distance){
        if(root == null){
            return;
        }

        if (tm.get(distance) == null) {
            tm.put(distance, root.data);
        }

        topView(root.left, tm, distance-1);
        topView(root.right, tm, distance+1);
    }

    void bottomVeiwPrint(BinaryTreeNode<Integer> root){
        TreeMap<Integer,ArrayList<Integer>> map = new TreeMap<>();
        verticalOrder(root, 0, map);

        for(Map.Entry<Integer,ArrayList<Integer>> m : map.entrySet()){
            ArrayList<Integer> result = m.getValue();
            System.out.println(m.getKey()+" = "+result.get(result.size() -1));
        }
    }

    boolean isChildrenSum(BinaryTreeNode<Integer> root){

        if(root == null){
            return true;
        }
        if(root.left == null && root.right == null){
            return true;
        }

        int sum = 0;
        if(root.left != null){
            sum += root.left.data;
        }
        if(root.right != null){
            sum += root.right.data;
        }
        return(sum == root.data && isChildrenSum(root.left) && isChildrenSum(root.right));
    }

    static boolean search(BinaryTreeNode<Integer> root,ArrayList<BinaryTreeNode<Integer>> path,int searchElement){
        if(root == null){ 
            return false;
        }
        path.add(root);
        if(root.data == searchElement){
            return true;
        }
        if(search(root.left, path, searchElement) || search(root.right, path, searchElement)){
            return true;
        }
        return false;
    }

    static BinaryTreeNode<Integer> LCA(BinaryTreeNode<Integer> root,int n1,int n2){
        ArrayList<BinaryTreeNode<Integer>> path1 = new ArrayList<>();
        ArrayList<BinaryTreeNode<Integer>> path2 = new ArrayList<>();
        if(search(root, path1, n1) || search(root, path2, n2)){
            return null;
        }
        for(int i=path1.size()-1;i>=0;i--){
            for(int j=path2.size()-1;j>=0;j--){
                if(path1.get(i) == path2.get(j)){
                    return path1.get(i);
                }
            }
        }
        return null;
    }
}

public class BasicTreeExample {
    public static void main(String[] args) {
        System.out.println("Binary Tree Operations");

        BinaryTreeNode<Integer> root = null;

        while (true) {
            System.out.println("0 for exit");
            System.out.println("1 for insert data");
            System.out.println("2 for printting tree");
            System.out.println("3 for Preorder traversal");
            System.out.println("4 for Inorder traversal");
            System.out.println("5 for Postorder traversal");
            System.out.println("6 for Preorder traversal I");
            System.out.println("7 for Inorder traversal I");
            System.out.println("8 for Postorder traversal I");
            System.out.println("9 for BFT");
            System.out.println("10 for getting the height of the tree");
            System.out.println("11 for total number of nodes");
            System.out.println("12 to print left view");
            System.out.println("13 to print right view");
            System.out.println("14 for vertical order traversal");
            System.out.println("15 for top view of the tree");
            System.out.println("16 for bottom view of the tree");
            System.out.println("17 for checking chirldren sum of the tree");
            System.out.println("18 for LCA");
            System.out.println("enter a choice");

            Scanner sc = new Scanner(System.in);
            int choice = sc.nextInt();

            BasicTreeOprations obj = new BasicTreeOprations();

            switch (choice) {
                case 0:
                    return;
                case 1:
                    root = obj.insert();
                    break;

                case 2:
                    obj.print(root);
                    break;

                case 3:
                    obj.preOrder(root);
                    break;

                case 4:
                    obj.inOrder(root);
                    break;
                
                case 5:
                    obj.postOrder(root);
                    break;
                
                case 6:
                    // obj.preOrderIterative(root);
                    obj.preOrderIterative1(root);
                    break;

                case 7:
                    obj.inOrderIterative(root);
                    break;

                case 8:
                    obj.postOrderIterative(root);
                    break;

                case 9: 
                    // obj.BFT(root);
                    obj.BFT1(root);
                    break;

                case 10:
                   System.out.println("height = "+obj.height(root));
                    break;

                case 11:
                    System.out.println("total numbers of nodes = "+obj.numOfNodes(root));
                    break;

                case 12:
                    // obj.leftView(root,1);
                    // System.out.println();
                    obj.leftViewI(root);
                    break;
                
                case 13:
                    // obj.rightView(root, 1);
                    //System.out.println();
                    obj.rightViewI(root);
                    break;

                case 14:
                    // obj.PrintVerticalOrder(root);
                    List<List<Integer>> ans = obj.verticalTraversal(root);
                    for (List<Integer> innerList : ans) {
                        System.out.println(innerList);
                    }
                    break;

                case 15:
                    TreeMap<Integer,Integer> tm = new TreeMap<>();
                    obj.topView(root,tm,0);
                    for(Map.Entry<Integer,Integer> map : tm.entrySet()){
                        System.out.println(map.getKey()+" = "+map.getValue());
                    }
                    break;

                case 16:
                    obj.bottomVeiwPrint(root);
                    break;

                case 17:
                    System.out.println(obj.isChildrenSum(root));
                    break;
                
                case 18:
                    // System.out.println("first element");
                    // int n1 = sc.nextInt();
                    // System.out.println("second element");
                    // int n2 = sc.nextInt();
                    // BinaryTreeNode<Integer> res = LCA(root,n1,n2);
                    // System.out.println(res);
                    break;
                
                default:
                    break;
            }
        }
    }
}
