public class sudoku {

    static int maxSize = 9;
    public static boolean presentInRow(int row,char[][] board,char value){
        for(int col=0;col<maxSize;col++){
            if(board[row][col] == value){
                return true;
            }
        }
        return false;
    }

    public static boolean presentInCol(int col,char[][] board,char value){
        for(int row=0;row<maxSize;row++){
            if(board[row][col] == value){
                return true;
            }
        }
        return false;
    }

    public static boolean presentInSubGrid(int row,int col,char[][] board,char value){
        int startRow = row - row % 3;
        int startCol = col - col % 3;

        for(int i=startRow;i<startRow+3;i++){
            for(int j=startCol;j<startCol+3;j++){
                if(board[i][j] == value){
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean numberCanBePlaced(char[][] board,int row,int col,char value){
        return !presentInRow(row, board, value) && !presentInCol(col, board, value) && !presentInSubGrid(row, col, board, value);
    }

    public static boolean solveSudoku(char[][] board,int row,int col){
        if(col == maxSize){
            row = row + 1;
            col = 0;
        }
        if(row == maxSize){
            return true;
        }
        if(board[row][col] != '.'){
            return solveSudoku(board, row, col+1);
        }
        for(int i=1;i<=maxSize;i++){
            int value = i;
            if(numberCanBePlaced(board,row,col,(char)(value+'0'))){
                board[row][col] = (char)(value+'0');
                boolean result = solveSudoku(board, row, col+1);
                //stack falls
                if(result){
                    return true;
                }
                //negative stack falls
                board[row][col] = '.';
            }
        }
        return false;
    }
    public static void main(String[] args) {
        char[][] board = {
            {'5','3','.','.','7','.','.','.','.'},
            {'6','.','.','1','9','5','.','.','.'},
            {'.','9','8','.','.','.','.','6','.'},
            {'8','.','.','.','6','.','.','.','3'},
            {'4','.','.','8','.','3','.','.','1'},
            {'7','.','.','.','2','.','.','.','6'},
            {'.','6','.','.','.','.','2','8','.'},
            {'.','.','.','4','1','9','.','.','5'},
            {'.','.','.','.','8','.','.','7','9'}
        };

        if(solveSudoku(board,0,0)){
            for(int i=0;i<9;i++){
                for(int j=0;j<9;j++){
                    System.out.print(board[i][j]+" ");
                }
                System.out.println();
            }
        }
        else{
            System.out.println("not done");
        }

    }
}
