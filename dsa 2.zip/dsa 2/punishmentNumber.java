import java.util.ArrayList;

public class punishmentNumber {

    public static boolean check(int num){
        int square = num * num;
        int n = square;
        int sum = 0;

        while(n>0){
            int firstDigit = n % 10;
            sum += firstDigit;
            n = n / 10;
        }

        if(sum == num){
            return true;
        }
        return false;
    }

    public static int punishmentNumber1(int n){
        ArrayList<Integer> list = new ArrayList<>();
        for(int i=1;i<=n;i++){
            if(check(i)){
                list.add(i*i);
            }
        }

        int sum = 0;

        for(int i : list){
            sum += i;
        }

        return sum;
    }

    public static void main(String[] args) {
        int ans = punishmentNumber1(10);
        System.out.println(ans);
    }
}
