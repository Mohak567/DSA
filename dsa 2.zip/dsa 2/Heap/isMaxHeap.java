class TreeNode {
    int data;
    TreeNode left;
    TreeNode right;

    TreeNode(int data){
        this.data = data;
    }
    
}

public class isMaxHeap {
    public static boolean isMaxHeap(TreeNode root){
        return helper(root,Integer.MAX_VALUE);
    }

    public static boolean helper(TreeNode root,int parentvalue){
        if(root == null){
            return true;
        }
        if(root.data > parentvalue){
            return false;
        }
        return helper(root.left, root.data) && helper(root.right, root.data);
    }

    public static void main(String[] args) {

        TreeNode root = new TreeNode(50);
        root.left = new TreeNode(40);
        root.right = new TreeNode(30);
        root.left.left = new TreeNode(20);
        root.left.right = new TreeNode(10);

        System.out.println(isMaxHeap(root));
        
    }

}
