package Stack;

import java.util.Stack;

public class previousSmallerElement {
    public static void main(String[] args) {
        // int[] arr = {60,70,80,35,90,45,60};
        int[] arr = {60,50,40,85,90,60};
        Stack<Integer> st = new Stack<>();
        int[] ans = new int[arr.length];

        for(int i=0;i<arr.length;i++){
            while(!st.isEmpty() && st.peek() >= arr[i]){
                st.pop();
            }
            if(st.isEmpty()){
                ans[i] = -1;
            }
            else{
                ans[i] = st.peek();
            }
            st.push(arr[i]);
        }

        for(int i : ans){
            System.out.println(i);
        }
    }
}
