public class fibo {
    public static int find(int num){
        if(num<=1){
            return num;
        }
        return find(num-1) + find(num-2);
    }
    public static void main(String[] args) {
        System.out.println(find(7));
    }
}
