public class runningSum {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5};
        int[] sum = new int[arr.length];
        int temp = 0;
        for(int i=0;i<arr.length;i++){
            temp += arr[i];
            sum[i] = temp;
        }
        for (int i : sum) {
            System.out.print(i+" ,");
        }
    }
}
