package Graph;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class ShortestDistanceUnweighted {

    static void addEdge(ArrayList<ArrayList<Integer>> adj,int v,int u){
        adj.get(u).add(v);
        adj.get(v).add(u);
    }

    static void BFS(ArrayList<ArrayList<Integer>> adj,int V,int source,int[] distance){
        boolean[] visited = new boolean[V];
        Queue<Integer> q = new LinkedList<>();
        visited[source] = true;
        q.offer(source);
        while (!q.isEmpty()) {
            int u = q.poll();
            for(int v : adj.get(u)){
                if(visited[v] == false){
                    distance[v] = distance[u] + 1;
                    visited[v] = true;
                    q.add(v);
                }
            }
        }
    }

    public static void main(String[] args) {
        int totalVertex = 4;
        ArrayList<ArrayList<Integer>> adj = new ArrayList<>();
        for(int i=0;i<totalVertex+1;i++){
            adj.add(new ArrayList<>());
        }
        addEdge(adj, 0, 1);
        addEdge(adj, 1, 2);
        addEdge(adj, 2, 3);
        addEdge(adj, 0, 2);
        addEdge(adj, 1, 3);

        int[] distance = new int[totalVertex];

        for(int i=0;i<distance.length;i++){
            distance[i] = Integer.MAX_VALUE;
        }
        int source = 0;
        distance[source] = 0;
        BFS(adj, totalVertex, source, distance);

        for(int i=0;i<distance.length;i++){
            System.out.println(distance[i]);
        }
    }
}
