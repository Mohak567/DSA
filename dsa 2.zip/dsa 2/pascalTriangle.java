public class pascalTriangle {
    public static void pattern(int numRows){
        for(int i=0;i<numRows;i++){
            for(int k=0;k<numRows-i;k++){
                System.out.print(" ");
            }
            for(int j=0;j<=i;j++){
                System.out.print(pascalLogic(i,j)+" ");
            }
            System.out.println();
        }
    }
    public static int pascalLogic(int row,int col){
        if(col == 0 || row == col){
            return 1;
        }
        else{
            return pascalLogic(row-1, col-1) + pascalLogic(row-1, col);
        }
    }
    public static void main(String[] args) {
        int numRows = 5;
        pattern(numRows);
    }
}
