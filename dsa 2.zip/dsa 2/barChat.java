public class barChat {
    public static void main(String[] args) {
        int[] arr = {1,2,5,9,6,9};
        int largest = 0;
        for(int i=0;i<arr.length;i++){
            if(largest<arr[i]){
                largest = arr[i];
            }
        }
        int min = 1;
        for(int i=largest;i>=min;i--){
            for(int j=0;j<arr.length;j++){
                if(arr[j] >= i){
                    System.out.print("*\t");
                }
                else{
                    System.out.print("\t");
                }
            }
            System.out.println();
        }
    }
}
