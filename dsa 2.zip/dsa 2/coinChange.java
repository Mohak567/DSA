public class coinChange {
    static int findPossibleWays(int[] arr,int index,int target){
        if(target == 0){
            return 1;
        }
        if(target<0){
            return 0;
        }
        if(target > 0 && arr.length == index){
            return 0;
        }
        return findPossibleWays(arr, index, target - arr[index]) + findPossibleWays(arr, index+1, target);
    }
    public static void main(String[] args) {
        int[] arr = {1,2,3,4};
        System.out.println(findPossibleWays(arr,0,3));
    }
}
