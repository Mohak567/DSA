import java.util.Collections;
import java.util.PriorityQueue;

public class RunningMedian {

    static void compute(int[] arr){
        PriorityQueue<Integer> min= new PriorityQueue<>();
        PriorityQueue<Integer> max = new PriorityQueue<>(Collections.reverseOrder());
        for(int i=0;i<arr.length;i++){

            if(max.isEmpty() || max.peek() >= arr[i]){
                max.offer(arr[i]);
            }
            else{
                min.offer(arr[i]);
            }

            if(max.size() > min.size()+1){
                min.offer(max.poll());
            }
            else if (max.size() < min.size()) {
                max.offer(min.poll());
            }

            if(max.size() == min.size()){
                System.out.println((min.peek()+max.peek())/2.0);
            }
            else{
                System.out.println(max.peek());
            }
        }
    }

    public static void main(String[] args) {
        int[] arr = {2,0,7,9,5,4,5,4,1,6};
        compute(arr);
    }
}
