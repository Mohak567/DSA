package TwoDArray;

public class findKLargeNumbers {
    public static void main(String[] args) {
        int[] arr = {5,8,1,3,9,7,6};
        int k = 3;
        int[] ans = new int[arr.length-(k-1)];
        int max = 0;
        for(int i=0;i<=arr.length-k;i++){
            for(int j=i;j<k+i;j++){
                if(max < arr[j]){
                    max = arr[j];
                }
            }
            ans[i] = max;
        }

        for(int i : ans){
            System.out.println(i);
        }
    }
}
