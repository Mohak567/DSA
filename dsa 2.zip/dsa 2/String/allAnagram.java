import java.util.Arrays;

public class allAnagram {
    public static void main(String[] args) {
        String[] words = {"act", "dog", "cat", "god"};
        
        Arrays.sort(words);
        String[] wordClone = words.clone();
        int index = 0;
        for(String s : wordClone){
            char[] arr = s.toCharArray();
            Arrays.sort(arr);
            wordClone[index] = String.valueOf(arr);
            index++;
        }

        for(int i=0;i<words.length-1;i++){
            if(wordClone[i].equals(wordClone[i+1])){
                System.out.println(words[i]+" ,"+words[i+1]);
            }
        }
    }
}
