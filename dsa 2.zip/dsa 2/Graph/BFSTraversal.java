package Graph;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class BFSTraversal {
    static void addEdge(ArrayList<ArrayList<Integer>> adj,int u,int v){
        adj.get(v).add(u);
        adj.get(u).add(v);
    }

    static void bfs(ArrayList<ArrayList<Integer>> adj,int v){
        boolean[] visited = new boolean[v+1];
        Queue<Integer> q = new LinkedList<>();
        int source = 1;
        visited[source] = true;
        q.offer(source);
        while (!q.isEmpty()) {
            source = q.poll();
            System.out.print(source+",");
            int size = adj.get(source).size();
            for(int i=0;i<size;i++){
                int adjNode = adj.get(source).get(i);
                if(visited[adjNode] == false){
                    visited[adjNode] = true;
                    q.offer(adjNode);
                }
            }
        }
    }
    
    public static void main(String[] args) {
        ArrayList<ArrayList<Integer>> adj = new ArrayList<>();
        int totalVertex = 6;
        for(int i=0;i<totalVertex+1;i++){
            adj.add(new ArrayList<>());
        }

        addEdge(adj,1,2);
        addEdge(adj,1,3);
        addEdge(adj,2,4);
        addEdge(adj, 2, 5);
        addEdge(adj, 3, 5);
        addEdge(adj, 4, 5);
        addEdge(adj, 4, 6);
        addEdge(adj, 5, 6);
        bfs(adj, totalVertex);
    }
}
