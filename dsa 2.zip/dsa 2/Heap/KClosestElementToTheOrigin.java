import java.util.PriorityQueue;

public class KClosestElementToTheOrigin {

    static void compute(int[][] arr,int k){
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();
        for(int i=0;i<arr.length;i++){
            int num1 = arr[i][0] * arr[i][0];
            int num2 = arr[i][1] * arr[i][1];
            int ans = (int)Math.sqrt(num1 + num2);
            minHeap.add(ans);
        }

        for(int i=0;i<k;i++){
            System.out.println(minHeap.poll());
        }
    }

    public static void main(String[] args) {
        int[][] arr = {
            {-2,-2},
            {5,2},
            {-2,5},
            {-4,4},
        };

        int k = 2;
        compute(arr,k);
    }
}
