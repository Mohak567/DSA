package Stack;

import java.util.Stack;

public class validBrackets {

    public static boolean check(String str){
        Stack<Character> stack = new Stack<>();

        for(int i=0;i<str.length();i++){
            char ch = str.charAt(i);
            if(ch == '(' || ch == '{' || ch == '['){
                stack.push(ch);
            }
            else{
                if(stack.isEmpty()){
                    return false;
                }
                else if(pair(stack.peek(), ch)){
                    stack.pop();
                }
            }
        }
        return stack.isEmpty();
    }

    public static boolean pair(char a,char b){
        if(a == '(' && b == ')'){
            return true;
        }
        if(a == '{' && b == '}'){
            return true;
        }
        if(a == '[' && b == ']'){
            return true;
        }
        return false;
    }
    public static void main(String[] args) {
        String str = "((({[]})))";
        
        System.out.println(str.length()%2 == 0 ? check(str) : "false");
    }
}
