public class subsequence1 {
    static void find(String str,String currentString){
        if(str.length() == 0){
            System.out.println(currentString);
            return;
        }
        char c = str.charAt(0);
        String smallString = str.substring(1);
        find(smallString, currentString);
        find(smallString, currentString + c);
    }
    public static void main(String[] args) {
        find("abc","");
    }
}
