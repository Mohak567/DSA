public class RatInAMaze {

    public static boolean pathIsOpen(int[][] maze,int row ,int col){
        if(row >= 0 && row < maze.length && col >= 0 && col < maze[0].length && maze[row][col] == 1){
            return true;
        }
        return false;
    }

    public static boolean findPath(int[][] maze,int[][] path,int row,int col){

        if(row == maze.length - 1 && col == maze.length - 1){
            path[row][col] = 1;
            return true;
        }

        if(row<maze.length && col<maze[0].length){
            if(pathIsOpen(maze,row,col)){
                path[row][col] = 1;
                if(findPath(maze, path, row+1, col)){
                    return true;
                }
                if(findPath(maze, path, row, col+1)){
                    return true;
                }
                // if(findPath(maze, path, row, col-1)){
                //     return true;
                // }
                path[row][col] = 0;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        int[][] maze = {
            {1,1,1,0,1,0},
            {0,1,1,1,1,0},
            {0,0,0,1,0,0},
            {1,1,1,1,1,0},
            {0,1,0,0,1,0},
            {0,1,1,1,1,0}
    };
        int[][] path = new int[maze.length][maze.length];
        boolean ans = findPath(maze,path,0,0);
        if(ans){
            for(int i=0;i<maze.length;i++){
                for(int j=0;j<maze.length;j++){
                    System.out.print(path[i][j]+" ");
                }
                System.out.println();
            }   
        }
    }
}
