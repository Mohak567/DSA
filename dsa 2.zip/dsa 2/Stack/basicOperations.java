package Stack;

public class basicOperations {
    static public class MyStack{
        int[] arr;
        int top;
        int capacity;

        public MyStack(int c){
            capacity = c;
            arr = new int[capacity];
            top = -1;
        }

        public void push(int data){
            if(top == capacity -1){
                System.out.println("Overflow");
                return;
            }
            else{
                arr[++top] = data;
                System.out.println(arr[top]+" element is pushed into stack/array");
            }
        }

        public void pop(){
            if(top == -1){
                System.out.println("Underflow");
                return;
            }
            else{
                System.out.println(arr[top--]+" element has been removed");
                return;
            }
        }

        public int peek(){
            if(top == -1){
                return -1;
            }
            return arr[top];
        }

        public int size(){
            if(top == -1){
                return -1;
            }
            return top + 1;
        }

        public boolean isEmpty(){
            // if(top == -1){
            //     return true;
            // }
            // return false;

            return(top == -1);
        }

    }
    public static void main(String[] args) {
        MyStack obj = new MyStack(5);
        obj.push(10);
        obj.push(20);
        obj.push(30);
        obj.push(40);
        obj.pop();
        System.out.println(obj.size());
        System.out.println(obj.isEmpty());
        System.out.println(obj.peek());
        obj.pop();
        obj.pop();
        obj.pop();
        obj.push(1);
        System.out.println(obj.size());
    }
}
