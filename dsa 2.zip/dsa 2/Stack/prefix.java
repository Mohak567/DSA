package Stack;

import java.util.Stack;

public class prefix {

    // public static int reverse(int num) {
    //     int reversed = 0;
    //     while (num > 0) {
    //         reversed = reversed * 10 + (num % 10);
    //         num = num / 10;
    //     }
    //     return reversed;
    // }

    public static int computePrefix(String str) {
        Stack<Integer> st = new Stack<>();
        int i = str.length() - 1;

        while (i >= 0) {
            char c = str.charAt(i);
            if (Character.isDigit(c)) {
                int num = 0;
                int place = 1;

                while (i >= 0 && Character.isDigit(str.charAt(i))) {
                    num = (str.charAt(i) - '0') * place + num;
                    place *= 10;
                    i--;
                }

                st.push(num);
            } else if (c == ' ') {
                i--;
            } else {
                int a = st.pop();
                if(st.isEmpty()){
                    return -1;
                }
                int b = st.pop();
                int ans = 0;

                switch (c) {
                    case '+':
                        ans = a + b;
                        break;
                    case '-':
                        ans = a - b;
                        break;
                    case '*':
                        ans = a * b;
                        break;
                    case '/':
                        ans = a / b;
                        break;
                    case '%':
                        ans = a % b;
                        break;
                }
                st.push(ans);
                i--;
            }
        }
        return st.peek();
    }

    public static void main(String[] args) {
        String str = "-* 10 12 4";
        int ans = computePrefix(str);
        System.out.println(ans == -1 ? "not a valid string" : ans);
    }
}
