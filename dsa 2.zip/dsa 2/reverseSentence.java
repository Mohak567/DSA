public class reverseSentence {

    public static String reverse(String str){
        int i = 0,j = str.length() - 1;
        char[] words = str.toCharArray();

        while(i<j){

            char temp = words[i];
            words[i] = words[j];
            words[j] = temp;
            i++;j--;
        }

        return String.valueOf(words);
    }
    public static void main(String[] args) {
        String str = "hello from here";
        String rev = reverse(str);
        String[] words = rev.split(" ");
        String ans = "";
        for(String s : words){
            ans = ans + " " + reverse(s);
        }
        System.out.println(ans);
    }
}
