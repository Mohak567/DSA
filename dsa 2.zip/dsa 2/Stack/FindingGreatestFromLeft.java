package Stack;

import java.util.Stack;

public class FindingGreatestFromLeft {
    public static void main(String[] args) {
        int[] arr = {60,50,40,30,85,90,60};
        Stack<Integer> st = new Stack<>();
        int[] ans = new int[arr.length];

        ans[0] = -1;
        st.push(arr[0]);
        for(int i=1;i<arr.length;i++){
            if(arr[i] > st.peek()){
                while(!st.isEmpty()){
                    st.pop();
                }
                st.push(arr[i]);
                ans[i] = -1;
            }
            else{
                ans[i] = st.peek();
            }
        }
        for(int i : ans){
            System.out.println(i);
        }
    }
}
