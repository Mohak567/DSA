public class patternMatching {
    public static boolean findPattern(int i,int j,String str,String find){
        while(str.charAt(i) == find.charAt(j)){
            i++;j++;
            if(j == find.length()){
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
        String str = "abccbcdba";
        String find = "bcdb";

        for(int i=0;i<str.length();i++){
            if(str.charAt(i) == find.charAt(0) && findPattern(i,0,str,find)){
                System.out.println(i);
                return;
            }
        }
        System.out.println("not found");
    }
}
