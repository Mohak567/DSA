import java.util.ArrayList;

public class LCPSubSequence {
    public static ArrayList<String> findSubSequence(String s){
        ArrayList<String> list = new ArrayList<>();
        for(int i=0;i<s.length();i++){
            char c = s.charAt(i);
            if(list.size() == 0){
                list.add("");
                list.add(""+c);
                continue;
            }
            int subLength = list.size();
            for(int j=0;j<subLength;j++){
                String temp = list.get(j) + c;
                list.add(temp);
            }
        }
        return list;
    }

    static String lcsSubSeq(ArrayList<String> list1,ArrayList<String> list2){
        String ans = "";
        for(String word1 : list1){
            for(String word2 : list2){
                if(word1.equals(word2) && word1.length()>ans.length()){
                    ans = word1;
                }
            }
        }
        return ans;
    }
    public static void main(String[] args) {
        String s = "abzc";
        String s2 = "ayzc";
        ArrayList<String> list = findSubSequence(s);
        ArrayList<String> list2 = findSubSequence(s2);
        System.out.println(lcsSubSeq(list,list2));
    }
}
