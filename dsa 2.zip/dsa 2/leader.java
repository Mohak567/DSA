import java.util.ArrayList;

public class leader {
    public static void main(String[] args) {
        ArrayList<Integer> al = new ArrayList<>();
        int[] arr = {16,17,4,3,5,2};
        int largest = 0;
        for(int i=arr.length-1;i>=0;i--){
            if(i==arr.length-1){
                largest = arr[i];
                al.add(arr[i]);
            }
            else if(largest < arr[i] ){
                largest = arr[i];
                al.add(arr[i]);
            }
        }
        System.out.println(al);
    }
}
