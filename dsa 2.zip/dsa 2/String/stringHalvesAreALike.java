public class stringHalvesAreALike {
    static int check(String str){
        int freq = 0;
        for(int i=0;i<str.length();i++){
            if(str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u'){
                freq++;
            }
        }
        return freq;
    }
    public static void main(String[] args) {
        String s = "leeetcodde";
        String s1 = s.substring(0,(s.length()/2));
        String s2 = s.substring((s.length()/2),s.length());
        int forS1 = check(s1);
        int forS2 = check(s2);
        System.out.println(forS1 == forS2 ? "equal" : "not Equal");        
    }    
}