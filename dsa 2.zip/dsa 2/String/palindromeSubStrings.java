import java.util.ArrayList;

public class palindromeSubStrings {
    public static boolean check(String str){
        int i =str.length()-1;
        String temp = "";
        while(i>=0){
            temp = temp + str.charAt(i);
            i--;
        }
        return temp.equals(str);
    }
    public static void main(String[] args) {
        
        String str = "aabbccbac";
        ArrayList<String> list = new ArrayList<>();

        for(int i =0;i<str.length();i++){
            for(int j=i+1;j<str.length();j++){
                String temp = str.substring(i, j);
                // list.add(temp);
                if(check(temp)){
                    list.add(temp);
                }
            }
        }

        System.out.println(list);
    }
}
