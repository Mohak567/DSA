public class sorted_array {
    public static boolean check(int[] arr,int index){
        if(arr.length - 1 == index){
            return true;
        }
        if(arr[index]>arr[index+1]){
            return false;
        }
        return check(arr, index+1);
    }
    public static void main(String[] args) {
        int[] arr = {10,20,20,40,50};
        System.out.println(check(arr,0));
    }
}
