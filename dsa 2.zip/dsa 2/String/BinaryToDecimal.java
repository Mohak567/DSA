public class BinaryToDecimal {//easy
    public static void main(String[] args) {
        String s = "1111";
        int ans = 0;
        int twoKiPower = 1;
        for(int i=s.length()-1;i>=0;i--){
            int temp = s.charAt(i) - '0';
            ans += temp*(twoKiPower);
            twoKiPower *= 2;
        }
        System.out.println(ans);
    }
}
