package Stack;

import java.util.Stack;

public class postfix {

    public static int computePostfix(String str){
        Stack<Integer> st = new Stack<>();
        int i = 0;
        while (i < str.length()) {
            char c = str.charAt(i);

            if (Character.isDigit(c)) {
                int num = 0;
                while (i < str.length() && Character.isDigit(str.charAt(i))) {
                    num = num * 10 + (str.charAt(i) - '0');
                    i++;
                }
                st.push(num);
            } else if (c == ' ') {
                i++;
            } else {
                int b = st.pop();
                if(st.isEmpty()){
                    return -1;
                }
                int a = st.pop();
                switch (c) {
                    case '+':
                        st.push(a + b);
                        break;
                    case '-':
                        st.push(a - b);
                        break;
                    case '*':
                        st.push(a * b);
                        break;
                    case '/':
                        st.push(a / b);
                        break;
                    case '%':
                        st.push(a % b);
                        break;
                }
                i++;
            }
        }
        return st.peek();
    }
    public static void main(String[] args) {
        String str = "50 2 10 * -";
        int ans = computePostfix(str);
        System.out.println(ans == -1 ? "not a valid string" : ans);
    }
}
