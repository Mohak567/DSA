public class patternA {
    public static void printPattern(int row,int star,int cs){
        if(row == 0){
            System.exit(0);
            return;
        }
        if(star == 0){
            return;
        }
        System.out.print("*");
        printPattern(row,star-1,cs);
        System.out.println();
        star = cs;
        printPattern(row-1, star+1,cs+1);
    }
    public static void main(String[] args) {
        int max_row = 5;
        printPattern(max_row,1,1);
    }
}
