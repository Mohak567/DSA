public class putSignBetweenSame {
    public static void main(String[] args) {
        String s = "aabbbcacc";
        StringBuilder sb = new StringBuilder();
        sb.append(s.charAt(0));
        for(int i=1;i<s.length();i++){
            if(s.charAt(i-1) == s.charAt(i)){
                sb.append("*");
                sb.append(s.charAt(i));
            }
            else{
                sb.append(s.charAt(i));
            }
        }
        System.out.println(sb.toString());
    }
}
