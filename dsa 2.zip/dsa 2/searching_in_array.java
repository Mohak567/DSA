public class searching_in_array {
    public static int search(int[] arr,int index,int x){
        if(arr[index] == x){
            return index+1;
        }
        if(arr.length-1 == index){
            return -1;
        }
        return search(arr, index+1,x);
    }
    public static int searchL(int[] arr,int index,int x){
        if(arr[index] == x){
            return index+1;
        }
        if(index == 0){
            return -1;
        }
        return searchL(arr, index-1,x);
    }
    public static void main(String[] args) {
        int[] arr = {1,6,7,9,3,4,1,5,2};
        System.out.println(search(arr, 0, 1));
        System.out.println(searchL(arr,arr.length-1, 1));
    }
}
