class sum_of_digit{

    public static void sod(int n,int sum){
        if(n == 0){
            System.out.println("sum = "+sum);
            return;
        }
        int sd = n % 10;
        sum += sd;
        sod(n/10, sum);
    }

    public static int sodR(int n){
        if(n == 0){
            return 0;
        }
        int sum = sodR(n/10);
        int sd = n % 10;
        sum += sd;
        return sum;
    }

    public static int sodF(int n){
        int nn = n;
        int sum = 0;
        while(nn > 0){
            int temp = nn % 10;
            nn = nn / 10;
            sum += temp;
        }
        return sum;
    }
    public static void main(String[] args) {
        int n = 456123;
        sod(n,0);
        System.out.println(sodR(n));
        System.out.println(sodF(n));
    }
}