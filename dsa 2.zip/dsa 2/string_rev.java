public class string_rev {
    public static String srev(String str){
        if(str.length() == 0){
            return "";
        }
        String temp = str.substring(1);
        String smallresult = srev(temp);
        char c = str.charAt(0);
        return smallresult+c;
    }
    public static void main(String[] args) {
        String s = "hello";
        // String result = "";
        // for(int i=s.length()-1;i>=0;i--){
        //     char c = s.charAt(i);
        //     result += c;
        // }
        // System.out.println(result);
        System.out.println(srev(s));
    }
}
