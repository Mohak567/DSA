public class WindowSlidingFrequency {
    public static void main(String[] args) {
        int[] arr = {1,2,3,2,4,5,6,2,8,2,2,2};
        int k = 3;
        int x = 2;
        int frequency = 0;
        for(int i=0;i<k;i++){
            if(arr[i] == x){
                frequency++;
            }
        }
        System.out.println(frequency);

        for(int i=k;i<arr.length;i++){
            int outElement = arr[i-k];
            if(outElement == x){
                frequency--;
            }
            int inElement = arr[i];
            if(inElement == x){
                frequency++;
            }
            System.out.println(frequency);
        }
    }    
}
