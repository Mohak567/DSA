public class palindrome {
    public static String reverse(String str){
        if(str.length() == 0){
            return "";
        }
        String temp = str.substring(1);
        String smallResult = reverse(temp);
        char c = str.charAt(0);
        return smallResult + c;
    }
    public static void main(String[] args) {
        String str = "oio";
        String result = reverse(str);
        boolean ans = result.matches(str);
        System.out.println(ans);
    }
}
