
public class gasStation {

    public static int findStatingPoint(int[] gasStation,int[] cost){
        int startingPoint = 0;
        int surplus = 0;
        int deficit = 0;

        for(int i=0;i<gasStation.length;i++){
            surplus += gasStation[i] - cost[i];
            if(surplus < 0){
                startingPoint++;
                deficit += surplus;
                surplus = 0;
            }
        }
        if((deficit+surplus) >= 0){
            return startingPoint;
        }
        return -1;
    }
    public static void main(String[] args) {
        int[] gasStation = {1,2,3,4,5};
        int[] cost = {3,4,5,1,2};
        System.out.println(findStatingPoint(gasStation, cost));
    }
}
