package Stack;

import java.util.Stack;

public class nextSmallerElement {
    public static void main(String[] args) {
        int[] arr = {60,70,85,90,35,100,20};
        Stack<Integer> st = new Stack<>();
        int[] ans = new int[arr.length];

        //iterrative

        // for(int i=0;i<arr.length;i++){
        //     ans[i] = -1;
        // }

        // for(int i=0;i<arr.length-1;i++){
        //     for (int j = i+1; j < arr.length; j++) {
        //         if(arr[i] > arr[j]){
        //             ans[i] = arr[j];
        //             break;
        //         }
        //     }
        // }

        for(int i=arr.length -1;i>=0;i--){
            while (!st.isEmpty() && st.peek() >= arr[i]) {
                st.pop();
            }
            if(st.isEmpty()){
                ans[i] = -1;
            }
            else{
                ans[i] = st.peek();
            }
            st.push(arr[i]);
        }

        for(int i : ans){
            System.out.println(i);
        }
    }
}
