public class ProfitDays {

    public static int[] find(int[] prices){

        int[] ans = new int[prices.length];
        
        for(int i=0;i<prices.length;i++){
            int j = i-1;
            int count = 1;
            while(j>=0 && prices[i] >= prices[j]){
                count++;
                j--;
            }
            ans[i] = count;
        }
        return ans;
    }
    public static void main(String[] args) {
        int[] prices = {60,40,50,70,85,90,60};
        int[] ans = find(prices);
        for(int i:ans){
            System.out.println(i);
        }
    }
}
