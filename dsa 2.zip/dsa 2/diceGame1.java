public class diceGame1 {
    static int totalOutcomes = 0;
    static void find(int target,int current,String result){
        if(current == target){
            System.out.println(result);
            totalOutcomes++;
            return;
        }
        if(current>target){
            return;
        }
        for(int dice = 1;dice<=6;dice++){
            int newValue = current + dice;
            find(target, newValue, result+dice);
        }
    }
    public static void main(String[] args) {
        find(3,0,"");
        System.out.println("totalOutcomes = "+totalOutcomes);
    }
}
