import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

public class KMostOccuring {

    static void kMost(int[] arr,int k){
        Map<Integer,Integer> m = new HashMap<>();
        for(int i : arr){
            m.put(i, m.getOrDefault(i, 0)+1);
        }

        PriorityQueue<Map.Entry<Integer,Integer>> maxHeap = new PriorityQueue<>((a,b)-> b.getValue() - a.getValue());
        maxHeap.addAll(m.entrySet());
        for (int i = 0; i < k; i++) {
            System.out.println(maxHeap.poll().getKey());
        }
    }
    public static void main(String[] args) {
        int[] arr = {1,1,1,1,2,2,3,3,3,3,4,4,4,4,4};
        int k = 3;
        kMost(arr, k);
    }
}
