import java.util.ArrayList;

public class subsequence {

    public static ArrayList<String> Makesubsequence(String str){
        if(str.length() == 0){
            ArrayList<String> list = new ArrayList<>();
            list.add("");
            return list;
        }
        ArrayList<String> result = new ArrayList<>();
        char c = str.charAt(0);
        ArrayList<String> smallResult = Makesubsequence(str.substring(1));
        for (String s : smallResult) {
            //not include
            result.add(s);
            //include
            result.add(s + c);
        }

        return result;

    }
    public static void main(String[] args) {
        String str = "abc";
        ArrayList<String> ans = Makesubsequence(str);
        System.out.println(ans);
    }
}
