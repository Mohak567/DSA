package Stack;

import java.util.Stack;

public class profitDays {

  public static int[] find(int[] prices) {
    int[] ans = new int[prices.length];
    Stack<Integer> st = new Stack<>();
    for (int i = 0; i < prices.length; i++) {
      int j = i - 1;

      while (prices[j] <= prices[i] && j >= 0) {}
    }
    return ans;
  }

  public static void main(String[] args) {
    int[] prices = { 60, 40, 50, 70, 85, 90, 60 };
    int[] ans = find(prices);
    for (int i : ans) {
      System.out.println(i);
    }
    // Stack<Integer> st = new Stack<>();
    // st.push(1);
    // st.push(2);
    // st.push(3);
    // st.push(4);
    // st.push(5);
    // st.push(6);
    // st.push(7);
    // st.push(8);
    // st.push(9);
    // st.push(10);
    // st.push(11);
    // System.out.println(st.peek()+" peek");
    // System.out.println(st.pop()+" pop");
    // System.out.println(st.size()+" size");
    // System.out.println(st.contains(6)+" contains");
    // System.out.println(st.capacity()+" capacity");
    // System.out.println(st.reversed()+" reversed");
  }
}
