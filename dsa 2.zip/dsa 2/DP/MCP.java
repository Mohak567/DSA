package DP;

import java.util.Arrays;

public class MCP {

    static int Recur(int[][] mat,int r,int c){

        if(c < 0 || r < 0){
            return Integer.MAX_VALUE;
        }

        if(c == 0 && r == 0){
            return mat[r][c];
        }

        int left = Recur(mat,r,c-1);
        int up = Recur(mat, r-1, c);
        int dig = Recur(mat, r-1, c-1);


        return mat[r][c] + Math.min(dig, Math.min(left, up));
    }

    static int Memo(int[][] mat,int r,int c,int[][] cache){

        if(c < 0 || r < 0){
            return Integer.MAX_VALUE;
        }

        if(c == 0 && r == 0){
            cache[r][c] = mat[r][c];
            return mat[r][c];
        }

        if(cache[r][c] != -1) return cache[r][c];

        int left = Memo(mat,r,c-1,cache);
        int up = Memo(mat, r-1, c,cache);
        int dig = Memo(mat, r-1, c-1,cache);
        int ans = mat[r][c] + Math.min(dig, Math.min(left, up));

        mat[r][c] = ans;

        return ans;
    }

    static int Tab(int[][] mat){
        int[][] result = new int[mat.length][mat[0].length];
        result[0][0] = mat[0][0];
        //filling first col
        for(int i=1;i<mat.length;i++){
            result[i][0] = result[i-1][0] + mat[i][0];
        }

        //filling first row
        for(int i=1;i<mat.length;i++){
            result[0][i] = result[0][i-1] + mat[0][i];
        }

        for(int i=1;i<mat.length;i++){
            for(int j=1;j<mat[0].length;j++){
                result[i][j] = Math.min(result[i][j-1],Math.min(result[i-1][j-1], result[i-1][j])) + mat[i][j];
            }
        }

        return result[mat.length-1][mat[0].length-1];
    }

    public static void main(String[] args) {
        int[][] matrix = {
                        {2,0,6},
                        {3,1,7},
                        {4,5,9}
                        };

        // System.out.println(Recur(matrix,matrix.length-1,matrix[0].length-1));
        
        // int[][] cache = new int[matrix.length][matrix[0].length];
        // for(int i=0;i<cache.length;i++){
        //     for(int j=0;j<cache[0].length;j++){
        //         cache[i][j] = -1;
        //     }
        // }
        // System.out.println(Memo(matrix,matrix.length-1,matrix[0].length-1,cache));

        System.out.println(Tab(matrix));
    }
}
