public class palindromeS {
    public static void main(String[] args) {
        String str = "abcba";
        //approach - 1
        // String rev = "";
        // int i=0;
        // while(i<str.length()){
        //     rev = rev + str.charAt(i);
        //     i++;
        // }
        // System.out.println(str.equals(rev));

        int start = 0,end = str.length()-1;

        while(start<=end){
            if(str.charAt(start) == str.charAt(end)){
                start++;end--;
            }
            else{
                System.out.println("not Equal");
                return;
            }
        }
        System.out.println("equal");
    }
}
