package DP;

public class DiceCount {

    static int countWays(int target,int current){
        if(target == current) return 1;
        if(target < current) return 0;
        int count = 0;
        for(int i=1;i<=6;i++){
            count += countWays(target, current+i);
        }
        return count;
    }

    static int countWaysMem(int target,int current,int[] cache){
        if(target == current) return 1;
        if(target < current) return 0;
        if(cache[current] != 0) return cache[current];
        int count = 0;
        for(int i=1;i<=6;i++){
            count += countWaysMem(target, current+i,cache);
        }
        cache[current] = count;
        return count;
    }

    public static void main(String[] args) {
        int target = 5;
        // System.out.println(countWays(target,0));
        int[] cache = new int[target+1];
        System.out.println(countWaysMem(target, 0, cache));
    }
}
