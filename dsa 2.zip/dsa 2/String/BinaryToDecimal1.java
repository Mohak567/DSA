public class BinaryToDecimal1 {
    public static void main(String[] args) {
        String s = "1010";
        int ans = 0;
        int mask = 0;
        for(int i=s.length()-1;i>=0;i--){
            int bit = s.charAt(i) -'0';
            ans += bit<<mask;
            mask++;
        }
        System.out.println(ans);
    }
}
