package Stack;

import java.util.Stack;

public class sortUsingStack {
    public static void main(String[] args) {
        Stack<Integer> st = new Stack<>();
        st.push(34);
        st.push(15);
        st.push(96);
        st.push(45);
        st.push(50);
        st.push(12);

        Stack<Integer> s = new Stack<>();

        while(!st.isEmpty()){
            int temp = st.pop();
            while(!s.isEmpty() && s.peek()<temp){
                st.push(s.pop());
            }
            s.push(temp);
        }
        while (!s.isEmpty()) {
            System.out.println(s.pop());
        }
    }
}