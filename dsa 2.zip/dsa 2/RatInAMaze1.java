import java.util.ArrayList;

public class RatInAMaze1 {
    public static boolean pathIsOpen(int[][] maze,int row ,int col){
        if(row >= 0 && row < maze.length && col >= 0 && col < maze[0].length && maze[row][col] == 1){
            return true;
        }
        return false;
    }

    public static void findPath(int[][] maze,boolean[][] visited,int row,int col,StringBuilder sb,ArrayList<String> result){
        if(row<0 || col<0 || row>=maze.length || col>=maze.length || maze[row][col] == 0 || visited[row][col]){
            return ;
        }
        if(row == maze.length-1 && col == maze.length-1){
            result.add(sb.toString());
            return;
        }
        visited[row][col] = true;
        findPath(maze, visited, row+1, col, sb.append("D"), result);
        sb.deleteCharAt(sb.length() -1);
        findPath(maze, visited, row, col-1, sb.append("L"), result);
        sb.deleteCharAt(sb.length() -1);
        findPath(maze, visited, row, col+1, sb.append("R"), result);
        sb.deleteCharAt(sb.length() -1);
        findPath(maze, visited, row-1, col, sb.append("U"), result);
        sb.deleteCharAt(sb.length() -1);
        visited[row][col] = false;
    }

    public static void main(String[] args) {
        int[][] maze = {
            {1, 0, 0, 0},
            {1, 1, 0, 1},
            {1, 1, 0, 0},
            {0, 1, 1, 1}
    };
        boolean[][] visited = new boolean[maze.length][maze.length];
        ArrayList<String> result = new ArrayList<>();
        StringBuilder ans = new StringBuilder();
        findPath(maze,visited,0,0,ans,result);
        System.out.println(result);
    }
}
