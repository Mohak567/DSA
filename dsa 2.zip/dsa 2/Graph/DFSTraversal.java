package Graph;

import java.util.ArrayList;

public class DFSTraversal {

    static void addEdge(ArrayList<ArrayList<Integer>> adj,int u,int v){
        adj.get(v).add(u);
        adj.get(u).add(v);
    }

    static void dfsRec(ArrayList<ArrayList<Integer>> adj,int source,boolean[] visited){
        visited[source] = true;
        System.out.println(source+",");
        for(int i : adj.get(source)){
            if(visited[i] == false){
                dfsRec(adj, source, visited);
            }
        }
    }

    static void dfs(ArrayList<ArrayList<Integer>> adj,int v,int source){
        boolean[] visited = new boolean[v];
        // dfsRec(adj, source, visited);
        
        //for disconnected
        for(int i=0;i<v;i++){
            if(visited[i] == false){
                dfsRec(adj, i, visited);
            }
        }
    }

    public static void main(String[] args) {
        ArrayList<ArrayList<Integer>> adj = new ArrayList<>();
        int totalVertex = 4;
        for(int i=0;i<totalVertex;i++){
            adj.add(new ArrayList<>());
        }

        addEdge(adj,0,1);
        addEdge(adj,1,2);
        addEdge(adj,2,3);
        addEdge(adj,3,1);
    }
}
