import java.util.LinkedList;
import java.util.Queue;

public class circularWinner {

    public static int winner(int n,int k){
        return helper(n,k)+1;
    }

    public static int helper(int n,int k){
        if(n == 1){
            return 0;
        }
        return (helper((n-1), k)+k) % n;
    }

    static int winner1(int n,int k){
        Queue<Integer> q = new LinkedList<>();
        for(int i=1;i<=n;i++){
            q.offer(i);
        }
        while (q.size() > 1) {
            for(int i=0;i<k-1;i++){
                q.offer(q.poll());
            }
            q.poll();
        }

        return q.peek();
    }
    public static void main(String[] args) {
        int n = 8;
        // System.out.println(winner(n,3));
        System.out.println(winner1(n, 3));
    }
}
