public class ReplaceWithHash {
    public static String convert(String str, StringBuilder sb, int index) {
        if (index == str.length() - 1 ) {
            if(str.charAt(str.length()-1) == str.charAt(str.length()-2)){
                sb.append("#");
            }
            else{
                sb.append(str.charAt(index));
            }
            // System.out.println(sb);
            return sb.toString();
        }
        if(index == 0 || str.charAt(index) != str.charAt(index-1)){
            sb.append(str.charAt(index));
            // System.out.println(sb);
        }
        else{
            sb.append("#");
            // System.out.println(sb);
        }

        return convert(str, sb, index + 1);
    }

    public static void main(String[] args) {
        String str = "aaabbbcccasaaaaasssssmkllklklddddfsvjhasbk    s";
        StringBuilder sb = new StringBuilder();
        // sb.append(str.charAt(0));
        System.out.println(convert(str, sb, 0));

        // Using a for loop
        // System.out.print(str.charAt(0));
        // for (int i = 1; i < str.length(); i++) {
        //     char c = str.charAt(i);
        //     if (str.charAt(i - 1) == c) {
        //         System.out.print("#");
        //     } else {
        //         System.out.print(c);
        //     }
        // }
    }
}
