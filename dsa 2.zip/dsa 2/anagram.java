import java.util.Arrays;

public class anagram {
    public static boolean check(String s1,String s2){
        if(s1.length() != s2.length()){
            return false;
        }

        char[] a = s1.toCharArray();
        Arrays.sort(a);
        s1 = new String(a);

        char[] b = s2.toCharArray();
        Arrays.sort(b);
        s2 = new String(b);

        return s1.equals(s2);

    }
    public static void main(String[] args) {
        String str = "dog";
        String str1 = "god";
        System.out.println(check(str, str1));
    }
}
