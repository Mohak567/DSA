import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class makeTwoNumbersEqual {
    static void check(int[] arr,Queue<Integer> q){
        Stack<Integer> s = new Stack<>();
        for(int i=arr.length-1;i>=0;i--){
            s.push(arr[i]);
        }
        int count = 0;
        while(true){
            if(s.peek() == q.peek()){
                s.pop();
                q.poll();
                count = 0;
            }
            else{
                q.offer(q.poll());
                count++;
            }
            if(count == q.size()){
                break;
            }
        }
        System.out.println(count > 0 ? "not equal" : "equal");
    }

    //more optimize
    static int easy(int[] num1,int[] num2){
        int ones = 0;
        int zeros = 0;
		
        for(int num : num1){
            if(num == 0){
                zeros++;
            }
            else{
                ones++;
            }
        }
        
        for(int num : num2){
            if(num == 0){
                if(zeros == 0){
                    return ones;
                }
                zeros--;
            }
            else{
                if(ones == 0){
                    return zeros;
                }
                ones--;
            }
        }
        return 0;
    }
    public static void main(String[] args) {
        int[] arr = {1,0,0,1};
        int[] num2 = {1,0,1,0};
        Queue<Integer> q = new LinkedList<>();
        q.offer(1);
        q.offer(0);
        q.offer(1);
        q.offer(1);
        // check(arr, q);
        System.out.println(easy(arr,num2) > 0 ? "not equal" : "equal");
    }
}
