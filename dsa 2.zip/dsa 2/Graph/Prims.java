package Graph;

import java.util.Arrays;

public class Prims {

    static int prims(int[][] graph,int v){
        int[] key = new int[v];
        Arrays.fill(key, Integer.MAX_VALUE);
        key[0] = 0;
        boolean[] visited = new boolean[v];
        int result = 0;
        for(int i=0;i<v;i++){
            int source = -1;
            for(int j=0;j<v;j++){
                if(!visited[j] && (source == -1 || key[j] < key[source])){
                    source = j;
                }
            }
            visited[source] = true;
            result += key[source];
            for(int vertex = 0;vertex<v;vertex++){
                if(graph[source][vertex] != 0 && !visited[vertex]){
                    key[vertex] = Math.min(graph[source][vertex], key[vertex]);
                }
            }
        }
        return result;
    }

    public static void main(String[] args) {
        int[][] graph = {
            {0,5,8,0},
            {5,0,10,15},
            {8,10,0,20},
            {0,15,20,0}
        };
        int vertex = 4;
        System.out.println(prims(graph,vertex));
    }
}
