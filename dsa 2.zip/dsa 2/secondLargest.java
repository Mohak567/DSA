public class secondLargest {
    public static void main(String[] args) {
        int[] arr = {1, 32, 6, 7, 9, 10, 15 ,23 ,32};
        int largest = 0;
        int secondLargest = -1;
        for(int i=0;i<arr.length;i++){
            if(largest<arr[i]){
                secondLargest = largest;
                largest = arr[i];
            }
            else if(secondLargest < arr[i] && arr[i] < largest){
                secondLargest = arr[i];
            }
        }
        System.out.println("largest = "+largest);
        System.out.println("second largest = "+secondLargest);
    }
}
