import java.util.ArrayList;

public class diceGame {
    static ArrayList<String> find(int currentValue,int targetValue){
        if(currentValue == targetValue){
            ArrayList<String> result = new ArrayList<>();
            result.add("");
            return result;
        }
        if(currentValue > targetValue){
            ArrayList<String> result = new ArrayList<>();
            return result;
        }
        ArrayList<String> finalResult = new ArrayList<>();

        for(int dice = 1; dice <= 6; dice++){
            int newValue = dice + currentValue;
            ArrayList<String> list = find(newValue, targetValue);
            for(String s : list){
                finalResult.add(dice + s);
                // System.out.println(s+" S");
                // System.out.println(dice+" dice");
            }
        }
        return finalResult;
    }
    public static void main(String[] args) {
        ArrayList<String> ans = find(0,5);
        System.out.println(ans);
    }
}
