package CP;

import java.math.BigInteger;

public class BigNumberMultiplication {

    static String multiply(String a,String b){
        
    }
    
    public static void main(String[] args) {
        String a = "126767683545354354354";
        String b = "11155454544832";
        
    }
}
