public class power_of_two {
    public static void find(int num,int power,int current){
        if(num < current){
            System.out.println("not a power of 2");
            return;
        }
        else if(num == current){
            System.out.println("2 ki power "+power+" = "+num);
            return;
        }
        current = 2 * current;
        find(num, power+1, current);
    }
    public static void main(String[] args) {
        int num = 32;
        find(num,0,1);
    }
}
