public class pattern {
    public static void printStar(int star){
        if(star == 0){
            return;
        }
        System.out.print("*");
        printStar(star-1);
    }
    public static void printLine(int row,int star){
        if(row == 0){
            return;
        }
        printStar(star);
        System.out.println();
        printLine(row-1,star+1);
    }
    public static void main(String[] args) {
        int Max_row = 5;
        printLine(Max_row,1);
    }
}
