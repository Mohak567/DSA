import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class ReverseAQueue {

    static void rev(Queue<Integer> qu){
        Stack<Integer> st = new Stack<>();
        while (!qu.isEmpty()) {
            st.push(qu.poll());
        }
        while (!st.isEmpty()) {
            System.out.println(st.pop());
        };
    }

    static void rev1(Queue<Integer> qu){
        if(qu.isEmpty()){
            return;
        }
        int front = qu.poll();
        rev1(qu);
        qu.offer(front);
    }

    public static void main(String[] args) {
        Queue<Integer> qu = new LinkedList<>();
        qu.offer(0);
        qu.offer(1);
        qu.offer(2);
        qu.offer(6);
        qu.offer(7);
        rev(qu);
        rev1(qu);
    }
}
