package LinkedList;

import java.util.Scanner;

class Node<T>{
    T data;
    Node<T> next;
    Node(T data){
        this.data = data;
        this.next = null;
    }
}

public class LinkedListOperations<T> {
    Scanner sc = new Scanner(System.in);
    Node<T> head;
    Node<T> tail;
    int length = 0;

    void print(Node<T> start){
        Node<T> temp = start;
        while(temp != null){
            System.out.print(temp.data+", ");
            temp = temp.next;
        }
        System.out.println();
    }

    void add(T data){
        Node<T> newNode = new Node<>(data);
        if(head == null){
            head = newNode;
            tail = newNode;
        }
        else{
            tail.next = newNode;
            tail = newNode;
        }
        length++;
    }

    void addAtPosition(int Position,T data){
        Node<T>newNode = new Node<>(data);
        if(Position == 0){
            newNode = head;
            head = newNode;
        }
        int i = 1;
        Node<T> temp = head;
        while(i<Position){
            temp = temp.next;
            i++;
        }
        newNode.next = temp.next;
        temp.next = newNode;
    }
    void deleteAtPosition(int Position){
        if(head == null){
            System.out.println("Linked list is empty");
            return;
        }
        Node<T> temp = head;
        if(Position == 0){
            // temp = head.next;
            // head = temp;
            head = temp.next;
            return;
        }
        int i=1;
        while(i<Position){
            temp = temp.next;
            i++;
        }
        temp.next = temp.next.next;

    }

    void detectCycleAndRemove(){
        Node<T> slow = head;
        Node<T> fast = head;

        while(fast != null && fast.next != null){
            slow = slow.next;
            fast = fast.next.next;
            if(fast == slow){
                System.out.println("Cycle present");
                break;
            }
        }
        if(slow != fast){
            System.out.println("no cycle present");
            return;
        }
        fast = head;
        slow = head;
        while(slow!=fast){
            slow = slow.next;
            fast = fast.next.next;
        }
        fast.next = null;
    }

    void getMiddleElement(){
        Node<T> slow = head;
        Node<T> fast = head;

        while(fast != null && fast.next != null){
            slow = slow.next;
            fast = fast.next.next;
        }
        System.out.println(slow.data);
    }
    
    void getElementFromLast(int k){
        Node<T> a = head;
        Node<T> b = head;

        for(int i=0;i<=k;i++){
            b = b.next;
        }

        while(b != null){
            a = a.next;
            b = b.next;
        }
        System.out.println("element from last at position = "+k+" is "+a.data);
    }
    public static void main(String[] args) {
        // Node<Integer> node1 = new Node<>(100);
        // Node<Integer> node2 = new Node<>(200);
        // node1.next = node2;
        // Node<Integer> node3 = new Node<>(300);
        // node2.next = node3;

        // LinkedListOperations<Integer> obj = new LinkedListOperations<>();
        // obj.print(node1);

        LinkedListOperations<Integer> obj = new LinkedListOperations<>();
        // obj.add(100);
        // obj.add(200);
        // obj.add(300);
        // obj.print(obj.head);

        Scanner sc = new Scanner(System.in);
        int choice = 0;

        while (true) {
            System.out.println("enter choice");
            System.out.println("1. for add");
            System.out.println("2. to print");
            System.out.println("3. to add a data at a specific position");
            System.out.println("4. for length of linked list");
            System.out.println("5. to delete at a position");
            System.out.println("6. detect cycle and remove");
            System.out.println("7. get middle element");
            System.out.println("8. find the element from the last");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("enter data");
                    obj.add(sc.nextInt());
                    break;
                case 2:
                    obj.print(obj.head);
                    break;
                case 3:
                    System.out.println("enter posistion");
                    int position = sc.nextInt();
                    System.out.println("enter data");
                    int data = sc.nextInt();
                    obj.addAtPosition(position, data);
                    break;
                case 4:
                    System.out.println("Length = "+obj.length);
                    break;
                case 5:
                    System.out.println("enter posistion");
                    int pos = sc.nextInt();
                    obj.deleteAtPosition(pos);
                    break;
                case 7:
                    obj.getMiddleElement();
                    break;
                case 8:
                    int posistion = sc.nextInt();
                    obj.getElementFromLast(posistion);
                    break;
                default:
                    System.out.println("wrong choice");
                    return;
            }
        }

    }
}
