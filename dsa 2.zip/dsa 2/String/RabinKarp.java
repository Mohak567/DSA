public class RabinKarp {
    //main logic is to build a hash function which can produce a unique hashvalue,which does not allow to frequently check the two strings
    //which has same hashvalue
    static long findHashValue(String Pattern){
        long hashValue = 0;
        long powerOf10 = 1;
        for(int i=0;i<Pattern.length();i++){
            hashValue += Pattern.charAt(i) * powerOf10;
            powerOf10 *= 10;
        }
        return hashValue;
    }

    static int findPattern(String text,long hashValue,String Pattern){
        boolean flag = false;
        for(int i=0;i<=text.length() - Pattern.length();i++){
            long temp = findHashValue(text.substring(i,i+Pattern.length()));
            if(temp == hashValue){
                flag = callForCheck(text.substring(i,i+Pattern.length()),Pattern);
                if(flag){
                    return i;
                }
            }
        }
        return -1;
    }

    static boolean callForCheck(String text,String Pattern){
        return text.equals(Pattern);
    }

    public static void main(String[] args) {
        String Pattern = "jajs";
        String text = "acjafjsbabjajsdab";
        long hashValue = findHashValue(Pattern);
        System.out.println(findPattern(text, hashValue,Pattern));
    }
}
